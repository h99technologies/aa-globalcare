#!/usr/bin/env bash
set -euo pipefail

# Run in a trusted CI environment. Never print the values of these variables.
: "${SUPABASE_DB_URL:?Set a private migration connection for Supabase PostgreSQL}"
: "${DATABASE_URL:?Set a private application PostgreSQL connection for the build}"
: "${SUPABASE_URL:?Set the Supabase project URL privately}"
: "${SUPABASE_PUBLISHABLE_KEY:?Set the Supabase publishable key privately}"

node scripts/migrate.mjs
npx opennextjs-cloudflare build
npx opennextjs-cloudflare deploy
