import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";
import pg from "pg";

const url = process.env.SUPABASE_DB_URL || process.env.DATABASE_URL;
if (!url) {
  console.error("A private SUPABASE_DB_URL or DATABASE_URL is required for migrations.");
  process.exit(1);
}

const client = new pg.Client({ connectionString: url, connectionTimeoutMillis: 10000 });
try {
  await client.connect();
  const files = (await readdir(join(process.cwd(), "migrations"))).filter((f) => /^\d+_[\w-]+\.sql$/.test(f)).sort();
  for (const file of files) {
    const version = file.replace(/\.sql$/, "");
    const table = await client.query("select to_regclass('public.app_migrations') as name");
    if (table.rows[0]?.name) {
      const applied = await client.query("select 1 from public.app_migrations where version = $1", [version]);
      if (applied.rowCount) { console.log(`Migration ${version}: already applied`); continue; }
    }
    const sql = await readFile(join(process.cwd(), "migrations", file), "utf8");
    await client.query(sql);
    console.log(`Migration ${version}: applied`);
  }
} catch {
  console.error("Migration failed. Verify database permissions and review the SQL migration in a private environment.");
  process.exitCode = 1;
} finally {
  await client.end().catch(() => undefined);
}
