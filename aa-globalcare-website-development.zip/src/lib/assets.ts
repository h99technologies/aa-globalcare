export type ImageAsset = {
  id: string;
  title: string;
  url: string;
  fallback: string;
  alt: string;
  category: "travel" | "visa" | "study" | "career" | "destinations" | "company" | "atmosphere";
};

const host = "https://h99uploader.gt.tc/uploads/";
export const logoUrl = `${host}img_20261007_182622_0fa12b04.png`;
const fallback = {
  travel: "/images/travel-fallback.jpg",
  visa: "/images/visa-fallback.jpg",
  study: "/images/study-fallback.jpg",
  career: "/images/career-fallback.jpg",
  destinations: "/images/destination-fallback.jpg",
  company: "/images/travel-fallback.jpg",
  atmosphere: "/images/hero-fallback.jpg",
};

const raw: Array<[string, string, string, ImageAsset["category"], string]> = [
  ["hero", "Main Hero: Airplane + World", "img_20261006_171030_e749f5b6.jpg", "atmosphere", "Airplane above the earth"],
  ["airplaneClose", "Airplane Close-Up", "img_20261006_171634_320bc220.jpg", "travel", "Airplane close-up"],
  ["earth", "Earth From Space", "img_20261006_171634_52b18c0b.jpg", "atmosphere", "Earth viewed from space"],
  ["globe", "Globe / World Travel", "img_20261006_171634_18d2cbc1.jpg", "destinations", "Globe representing world travel"],
  ["airport", "International Airport", "img_20261006_171634_4878eec9.jpg", "travel", "International airport terminal"],
  ["suitcase", "Traveller With Suitcase", "img_20261006_171634_0d238f86.jpg", "travel", "Traveller carrying a suitcase"],
  ["departure", "Airport Departure", "img_20261006_171634_70c7fa10.jpg", "travel", "Airport departure area"],
  ["window", "Airplane Window", "img_20261006_171634_d9fa2368.jpg", "travel", "View through an airplane window"],
  ["passport", "Passport + Visa", "img_20261006_171634_40e17be7.jpg", "visa", "Passport and visa documents"],
  ["visaConsultation", "Visa Consultation", "img_20261006_171634_2a4a3585.jpg", "visa", "Travel document consultation"],
  ["documents", "Document Preparation", "img_20261006_172045_6e8249e6.jpg", "visa", "Preparing application documents"],
  ["visaJourney", "Successful Visa / Journey", "img_20261006_172045_b6a4b498.jpg", "visa", "Travel journey planning"],
  ["student", "International Student", "img_20261006_172045_aaa9b6cf.jpg", "study", "International student"],
  ["studying", "Students Studying", "img_20261006_172045_b3d104b5.jpg", "study", "Students studying together"],
  ["campus", "University Campus", "img_20261006_172045_d0928aa5.jpg", "study", "University campus"],
  ["graduation", "Graduation", "img_20261006_172045_33b0173d.jpg", "study", "Graduation celebration"],
  ["professional", "International Professional", "img_20261006_172045_937df91e.jpg", "career", "Professional at work"],
  ["interview", "Job Interview", "img_20261006_172045_09109653.jpg", "career", "Professional interview meeting"],
  ["careerSuccess", "Career Success", "img_20261006_172045_0d0af3ca.jpg", "career", "Professional considering future opportunities"],
  ["canada", "Canada", "img_20261006_172045_9e329f68.jpg", "destinations", "View of Canada"],
  ["uk", "United Kingdom", "img_20261007_164210_30a2f0ad.jpg", "destinations", "View of the United Kingdom"],
  ["us", "United States", "img_20261007_164511_7ef8ed07.jpg", "destinations", "View of the United States"],
  ["uae", "United Arab Emirates", "img_20261007_164613_cdc765ac.jpg", "destinations", "View of the United Arab Emirates"],
  ["oman", "Oman", "img_20261007_164937_3fb7c985.jpg", "destinations", "View of Oman"],
  ["turkey", "Turkey", "img_20261007_165142_7871bb41.jpg", "destinations", "View of Turkey"],
  ["georgia", "Georgia", "img_20261007_165142_bfc8e0eb.jpg", "destinations", "View of Georgia"],
  ["albania", "Albania", "img_20261007_165142_3439f76a.jpg", "destinations", "View of Albania"],
  ["consultant", "Travel Consultant", "img_20261007_165142_25644a40.jpg", "company", "Travel consultant"],
  ["clientConsultation", "Client Consultation", "img_20261007_165142_cb1a2504.jpg", "company", "Consultation conversation"],
  ["team", "Professional Team / Company", "img_20261007_165142_4b0213b8.jpg", "company", "Professional team"],
  ["office", "Office", "img_20261007_170352_68f9959c.jpg", "company", "Office interior"],
  ["couple", "Couple Traveling", "img_20261007_170352_167a1159.jpg", "travel", "Couple traveling"],
  ["family", "Family Traveling", "img_20261007_170352_f97bd6f0.jpg", "travel", "Family traveling together"],
  ["businessTraveler", "Business Traveler", "img_20261007_170352_e6078a66.jpg", "travel", "Business traveler"],
  ["arrival", "Arrival", "img_20261007_170352_abb31208.jpg", "travel", "Traveler arriving at destination"],
  ["clouds", "Clouds", "img_20261007_170352_943b253c.jpg", "atmosphere", "Clouds in the sky"],
  ["worldMap", "World Map", "img_20261007_170352_8313087b.jpg", "destinations", "World map"],
  ["technology", "Abstract Blue Technology", "img_20261007_170352_760b5042.jpg", "atmosphere", "Abstract blue visual texture"],
  ["ocean", "Ocean / Earth", "img_20261007_170352_c4213b62.jpg", "atmosphere", "Ocean and earth"],
  ["journeyBegins", "Your Journey Begins", "img_20261007_170352_30148a0d.jpg", "travel", "Beginning a travel journey"],
  ["explore", "Explore the World", "img_20261007_170352_19bfad38.jpg", "destinations", "Exploring the world"],
  ["future", "Your Future Awaits", "img_20261007_170352_597a08bc.jpg", "career", "Looking toward future possibilities"],
  ["final", "Final CTA", "img_20261007_170352_1e98c345.jpg", "atmosphere", "Open horizon for a new journey"],
];

export const images = Object.fromEntries(raw.map(([id, title, file, category, alt]) => [id, {
  id, title, url: `${host}${file}`, fallback: fallback[category], alt, category,
}])) as Record<string, ImageAsset>;
export const imageLibrary = Object.values(images);

export type VideoAsset = { id: string; title: string; url: string; poster: string };
export const videos: Record<string, VideoAsset> = {
  hero: { id: "hero", title: "Hero airplane earth", url: "https://cdn.dbimg.app/hkFeSLnJ.mp4", poster: "/images/hero-fallback.jpg" },
  airplaneClouds: { id: "airplaneClouds", title: "Airplane clouds", url: "https://cdn.dbimg.app/CXSSkVce.mp4", poster: "/images/travel-fallback.jpg" },
  globe: { id: "globe", title: "Global travel globe", url: "https://cdn.dbimg.app/wsFzd5xB.mp4", poster: "/images/destination-fallback.jpg" },
  airport: { id: "airport", title: "International airport", url: "https://cdn.dbimg.app/ZdX7Vsms.mp4", poster: "/images/travel-fallback.jpg" },
  visa: { id: "visa", title: "Passport visa documents", url: "https://cdn.dbimg.app/E7XtMOkG.mp4", poster: "/images/visa-fallback.jpg" },
  study: { id: "study", title: "Study abroad campus", url: "https://cdn.dbimg.app/BnoQjECY.mp4", poster: "/images/study-fallback.jpg" },
  career: { id: "career", title: "International career", url: "https://cdn.dbimg.app/nG2oMcBF.mp4", poster: "/images/career-fallback.jpg" },
  cities: { id: "cities", title: "Global city destinations", url: "https://cdn.dbimg.app/toio98Dc.mp4", poster: "/images/destination-fallback.jpg" },
  suitcase: { id: "suitcase", title: "Traveller suitcase", url: "https://cdn.dbimg.app/X1ejZNmT.mp4", poster: "/images/travel-fallback.jpg" },
  takeoff: { id: "takeoff", title: "Aircraft takeoff sunset", url: "https://cdn.dbimg.app/bLfNuTpo.mp4", poster: "/images/hero-fallback.jpg" },
  clouds: { id: "clouds", title: "Clouds earth background", url: "https://cdn.dbimg.app/aJjZYMIr.mp4", poster: "/images/destination-fallback.jpg" },
  final: { id: "final", title: "Globalcare final journey", url: "https://cdn.dbimg.app/y4u1WUc4.mp4", poster: "/images/hero-fallback.jpg" },
};
