import "server-only";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import { db } from "@/db";
import { userRoles } from "@/db/schema";
import { eq } from "drizzle-orm";

export type ControlRole = "admin" | "developer";
export type ControlUser = { id: string; email: string; role: ControlRole };

export function isAuthConfigured() {
  return !!(process.env.SUPABASE_URL && process.env.SUPABASE_PUBLISHABLE_KEY);
}

export async function getSupabaseServer() {
  if (!isAuthConfigured()) return null;
  const cookieStore = await cookies();
  return createServerClient(process.env.SUPABASE_URL!, process.env.SUPABASE_PUBLISHABLE_KEY!, {
    cookies: {
      getAll() { return cookieStore.getAll(); },
      setAll(cookiesToSet) {
        // A Server Component may not write cookies; route handlers can. Auth is rechecked for every protected request.
        try {
          cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, {
            ...options, httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/",
          }));
        } catch { /* A read-only Server Component cannot refresh cookies. */ }
      },
    },
  });
}

export async function getControlUser(): Promise<ControlUser | null> {
  const supabase = await getSupabaseServer();
  if (!supabase) return null;
  try {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (error || !user) return null;
    const [row] = await db.select({ role: userRoles.role }).from(userRoles).where(eq(userRoles.userId, user.id)).limit(1);
    if (!row || !["admin", "developer"].includes(row.role)) return null;
    return { id: user.id, email: user.email || "Authenticated user", role: row.role };
  } catch { return null; }
}

export function canManage(user: ControlUser | null, required: "control" | "developer") {
  return !!user && (required === "control" || user.role === "developer");
}
