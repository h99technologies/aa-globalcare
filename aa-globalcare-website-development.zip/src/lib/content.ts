export const COMPANY = "A&A Globalcare Consultant Ltd.";
export const PHONE_ONE = "+237682081801";
export const PHONE_TWO = "+2348034759488";
export const PROVIDED_ADDRESS = "Shop C_9 Arotech Plaza AEDC. Office before Optima Filling Station ASO Road, Maraba, Abuja, Nigeria.";
export const DISCLAIMER = "Visa, admission, travel and employment decisions are made by the relevant authorities, institutions, carriers or employers. Requirements and outcomes vary. A&A Globalcare Consultant Ltd. does not guarantee approval, admission, employment or immigration outcomes. Please confirm the exact legal wording with the company.";

export type PublicSettings = {
  brandName: string;
  heroHeadline: string;
  heroSubheadline: string;
  introduction: string;
  address: string;
  addressConfirmed: boolean;
  phonePrimary: string;
  phoneSecondary: string;
  publicEmail: string | null;
  whatsapp: string | null;
  mapUrl: string | null;
  support24hConfirmed: boolean;
  siteStatus: "live" | "maintenance" | "suspended";
  statusMessage: string;
  disclaimer: string;
  privacyBody: string;
  termsBody: string;
  seoTitle: string;
  seoDescription: string;
  sectionOrder: string[];
};

export type PublicService = {
  id: string; slug: string; title: string; summary: string; body: string;
  includes: string[]; imageKey: string; videoKey: string; sortOrder: number; active: boolean;
};
export type PublicDestination = {
  id: string; country: string; slug: string; summary: string; serviceNotes: string;
  imageKey: string; videoKey: string; sortOrder: number; visible: boolean;
};
export type PublicFaq = { id: string; question: string; answer: string; category: string; sortOrder: number; published: boolean };
export type PublicAnnouncement = { id: string; title: string; body: string };
export type PublicTestimonial = { id: string; quote: string; displayName: string; roleLocation: string | null };
export type PublicGalleryItem = { id: string; title: string; assetUrl: string; alt: string; category: string; sortOrder: number };
export type PublicContent = { settings: PublicSettings; services: PublicService[]; destinations: PublicDestination[]; faqs: PublicFaq[]; announcements: PublicAnnouncement[]; testimonials: PublicTestimonial[]; gallery: PublicGalleryItem[] };

export const sectionIds = ["destinations", "services", "visa", "study", "career", "experience", "process", "about", "journal", "faqs", "contact"];

export const defaultSettings: PublicSettings = {
  brandName: COMPANY,
  heroHeadline: "Your Next Chapter Starts Beyond Borders.",
  heroSubheadline: "Thoughtful guidance for travel, visa applications, international study and career planning.",
  introduction: "A&A Globalcare Consultant Ltd. helps people explore international travel, study and career pathways with clear guidance and personalised support. Contact our team to discuss your goals and understand the next steps relevant to your destination.",
  address: PROVIDED_ADDRESS,
  addressConfirmed: false,
  phonePrimary: PHONE_ONE,
  phoneSecondary: PHONE_TWO,
  publicEmail: null,
  whatsapp: null,
  mapUrl: null,
  support24hConfirmed: false,
  siteStatus: "live",
  statusMessage: "We are making some improvements. Please contact us by phone while our website is unavailable.",
  disclaimer: DISCLAIMER,
  privacyBody: "DRAFT FOR COMPANY AND LEGAL REVIEW. We collect the details you submit in our enquiry form to respond to your request. We may share the relevant details with our team and configured notification providers to handle your enquiry. We do not sell enquiry details. Contact us by phone to request access, correction or deletion. Our retention schedule and applicable legal basis require owner confirmation before launch.",
  termsBody: "DRAFT FOR COMPANY AND LEGAL REVIEW. Information on this website is general guidance, not legal, immigration or financial advice. Services and requirements depend on your circumstances and destination. No outcome is guaranteed. Contact us to discuss the current scope of any service. Confirm all legal terms with the company before launch.",
  seoTitle: "A&A Globalcare Consultant Ltd. | Travel, Study & Career Guidance",
  seoDescription: "Explore travel bookings, visa application assistance, study abroad and career consultation with A&A Globalcare Consultant Ltd.",
  sectionOrder: sectionIds,
};

export const defaultServices: PublicService[] = [
  { id: "travel-bookings", slug: "travel-bookings", title: "Travel Bookings", summary: "Travel plans that begin with a conversation, not a complicated search.", body: "Explore local and international flight options with support tailored to your itinerary. We can help you think through routes, timing and the practical details of your journey.", includes: ["Local & international flight enquiries", "Itinerary planning support", "Travel preparation guidance"], imageKey: "airport", videoKey: "airport", sortOrder: 1, active: true },
  { id: "visa-assistance", slug: "visa-assistance", title: "Visa Assistance", summary: "A clearer way to navigate the application process.", body: "Get guidance for tourist, business, student and work visa applications. Requirements differ by destination and application type; decisions always rest with the relevant authorities.", includes: ["Understanding application requirements", "Document checklist guidance", "Preparation and next-step support"], imageKey: "passport", videoKey: "visa", sortOrder: 2, active: true },
  { id: "study-abroad", slug: "study-abroad", title: "Study Abroad", summary: "Make room for the education you imagine.", body: "Explore universities worldwide and understand the steps involved in planning an international education. We can help you organise your questions, documents and next steps.", includes: ["Exploring study options", "Entry-requirement discussions", "Application preparation support"], imageKey: "campus", videoKey: "study", sortOrder: 3, active: true },
  { id: "employment-programs", slug: "employment-programs", title: "Employment Programs", summary: "Think internationally about your next career chapter.", body: "Discuss your international career goals and the steps that may be relevant to them. Availability and eligibility depend on the destination and programme; employment outcomes are never guaranteed.", includes: ["Career goal conversations", "Pathway and requirement discussions", "Preparation guidance"], imageKey: "professional", videoKey: "career", sortOrder: 4, active: true },
];

const destinationNames: Array<[string, string, string]> = [
  ["Canada", "canada", "canada"], ["United Kingdom", "united-kingdom", "uk"],
  ["United States", "united-states", "us"], ["United Arab Emirates", "united-arab-emirates", "uae"],
  ["Oman", "oman", "oman"], ["Turkey", "turkey", "turkey"],
  ["Georgia", "georgia", "georgia"], ["Albania", "albania", "albania"],
];
export const defaultDestinations: PublicDestination[] = destinationNames.map(([country, slug, imageKey], i) => ({
  id: slug, country, slug,
  summary: `${country} appears on the company's supplied destination flyer. Ask us about current options and requirements before making plans.`,
  serviceNotes: "Destination shown on supplied material; current services and programme availability require company confirmation.",
  imageKey, videoKey: "cities", sortOrder: i + 1, visible: true,
}));

export const defaultFaqs: PublicFaq[] = [
  { id: "faq-1", question: "What services can A&A Globalcare help me explore?", answer: "We offer support with local and international travel bookings, tourist, business, student and work visa applications, study abroad exploration, and international career planning. Contact us to discuss the current scope of support for your situation.", category: "Services", sortOrder: 1, published: true },
  { id: "faq-2", question: "Which destinations can I ask about?", answer: "Our supplied material mentions Canada, the United Kingdom, the United States, the United Arab Emirates, Oman, Turkey, Georgia and Albania. These are candidate destinations, not a promise that every service is currently available in every location. Please enquire for current information.", category: "Destinations", sortOrder: 2, published: true },
  { id: "faq-3", question: "What documents will I need?", answer: "Requirements vary by destination, application type and the relevant authority or institution. After an initial conversation, we can help you understand what to check and prepare. Always confirm current requirements with official sources.", category: "Applications", sortOrder: 3, published: true },
  { id: "faq-4", question: "Can you guarantee a visa, admission or job?", answer: "No. Final decisions are made by the relevant authorities, institutions or employers. We provide guidance and preparation support; no approval, admission, employment or immigration outcome can be guaranteed.", category: "Process", sortOrder: 4, published: true },
  { id: "faq-5", question: "How do I begin?", answer: "Tell us what you are planning through the enquiry form or call one of the numbers on this site. We can discuss your goal and suggest appropriate next steps.", category: "Consultation", sortOrder: 5, published: true },
];

export const defaultContent: PublicContent = { settings: defaultSettings, services: defaultServices, destinations: defaultDestinations, faqs: defaultFaqs, announcements: [], testimonials: [], gallery: [] };
