import "server-only";
import { db } from "@/db";
import { announcements, destinations, faqs, gallery, integrationSettings, services, siteSettings, testimonials } from "@/db/schema";
import { and, asc, eq, gte, isNull, lte, or } from "drizzle-orm";
import { defaultContent, defaultSettings, type PublicContent, type PublicSettings } from "@/lib/content";

export function publicSettingsFromRow(row: typeof siteSettings.$inferSelect, whatsappVerified = false): PublicSettings {
  return {
    brandName: row.brandName, heroHeadline: row.heroHeadline, heroSubheadline: row.heroSubheadline,
    introduction: row.introduction, address: row.address, addressConfirmed: row.addressConfirmed,
    phonePrimary: row.phonePrimary, phoneSecondary: row.phoneSecondary,
    publicEmail: row.publicEmail, whatsapp: whatsappVerified ? row.whatsapp : null, mapUrl: row.mapUrl,
    support24hConfirmed: row.support24hConfirmed, siteStatus: row.siteStatus,
    statusMessage: row.statusMessage, disclaimer: row.disclaimer,
    privacyBody: row.privacyBody, termsBody: row.termsBody,
    seoTitle: row.seoTitle, seoDescription: row.seoDescription,
    sectionOrder: Array.isArray(row.sectionOrder) ? row.sectionOrder : defaultSettings.sectionOrder,
  };
}

export async function getPublicSettings(): Promise<PublicSettings> {
  try {
    const [[row], [integrations]] = await Promise.all([
      db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1),
      db.select({ whatsappVerified: integrationSettings.whatsappVerified }).from(integrationSettings).where(eq(integrationSettings.id, 1)).limit(1),
    ]);
    return row ? publicSettingsFromRow(row, integrations?.whatsappVerified) : defaultSettings;
  } catch { return defaultSettings; }
}

export async function getPublicContent(): Promise<PublicContent> {
  try {
    const now = new Date();
    const [settingsRows, integrationRows, serviceRows, destinationRows, faqRows, announcementRows, testimonialRows, galleryRows] = await Promise.all([
      db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1),
      db.select({ whatsappVerified: integrationSettings.whatsappVerified }).from(integrationSettings).where(eq(integrationSettings.id, 1)).limit(1),
      db.select().from(services).where(eq(services.active, true)).orderBy(asc(services.sortOrder)),
      db.select().from(destinations).where(eq(destinations.visible, true)).orderBy(asc(destinations.sortOrder)),
      db.select().from(faqs).where(eq(faqs.published, true)).orderBy(asc(faqs.sortOrder)),
      db.select({ id: announcements.id, title: announcements.title, body: announcements.body }).from(announcements).where(and(
        eq(announcements.status, "published"), or(isNull(announcements.startsAt), lte(announcements.startsAt, now)),
        or(isNull(announcements.endsAt), gte(announcements.endsAt, now)),
      )),
      db.select({ id: testimonials.id, quote: testimonials.quote, displayName: testimonials.displayName, roleLocation: testimonials.roleLocation })
        .from(testimonials).where(and(eq(testimonials.status, "approved"), eq(testimonials.consented, true))).orderBy(asc(testimonials.sortOrder)),
      db.select({ id: gallery.id, title: gallery.title, assetUrl: gallery.assetUrl, alt: gallery.alt, category: gallery.category, sortOrder: gallery.sortOrder })
        .from(gallery).where(eq(gallery.visible, true)).orderBy(asc(gallery.sortOrder)),
    ]);
    return {
      settings: settingsRows[0] ? publicSettingsFromRow(settingsRows[0], integrationRows[0]?.whatsappVerified) : defaultSettings,
      services: serviceRows.map((r) => ({ id: r.id, slug: r.slug, title: r.title, summary: r.summary, body: r.body,
        includes: Array.isArray(r.includes) ? r.includes : [], imageKey: r.imageKey, videoKey: r.videoKey, sortOrder: r.sortOrder, active: r.active })),
      destinations: destinationRows.map((r) => ({ id: r.id, country: r.country, slug: r.slug, summary: r.summary,
        serviceNotes: r.serviceNotes, imageKey: r.imageKey, videoKey: r.videoKey, sortOrder: r.sortOrder, visible: r.visible })),
      faqs: faqRows.map((r) => ({ id: r.id, question: r.question, answer: r.answer, category: r.category, sortOrder: r.sortOrder, published: r.published })),
      announcements: announcementRows, testimonials: testimonialRows, gallery: galleryRows,
    };
  } catch { return defaultContent; }
}
