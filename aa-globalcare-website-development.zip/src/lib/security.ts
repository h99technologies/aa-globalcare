import "server-only";
import { createHash, randomBytes } from "node:crypto";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { sql } from "drizzle-orm";

const runtimeSalt = randomBytes(32).toString("hex");

export function sameOrigin(request: Request) {
  const origin = request.headers.get("origin");
  const fetchSite = request.headers.get("sec-fetch-site");
  if (fetchSite === "cross-site") return false;
  if (!origin) return true; // Server-to-server clients have no Origin; cookies remain SameSite=Lax.
  try {
    const host = new URL(origin).host;
    return host === new URL(request.url).host || host === request.headers.get("x-forwarded-host");
  } catch { return false; }
}

export function acceptsJson(request: Request) {
  const type = request.headers.get("content-type") || "";
  const size = Number(request.headers.get("content-length") || "0");
  return type.startsWith("application/json") && size <= 20_000;
}
export function noStoreJson(body: unknown, status = 200) {
  return Response.json(body, { status, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
}

export async function rateLimit(scope: string, request: Request, max: number, seconds: number) {
  const ip = (request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown").slice(0, 90);
  const key = createHash("sha256").update(`${process.env.RATE_LIMIT_SALT || runtimeSalt}:${scope}:${ip}`).digest("hex");
  const result = await db.execute(sql`
    INSERT INTO public.rate_limits (key, count, expires_at)
    VALUES (${key}, 1, now() + make_interval(secs => ${seconds}))
    ON CONFLICT (key) DO UPDATE SET
      count = CASE WHEN public.rate_limits.expires_at <= now() THEN 1 ELSE public.rate_limits.count + 1 END,
      expires_at = CASE WHEN public.rate_limits.expires_at <= now() THEN now() + make_interval(secs => ${seconds}) ELSE public.rate_limits.expires_at END
    RETURNING count
  `);
  return Number(result.rows[0]?.count || 0) <= max;
}

export async function writeAudit(actorUserId: string | null, action: string, targetType: string, targetId?: string, safeMetadata: Record<string, string | number | boolean> = {}) {
  await db.insert(auditLogs).values({ actorUserId, action: action.slice(0, 100), targetType: targetType.slice(0, 80), targetId: targetId?.slice(0, 100), safeMetadata });
}

export function shortPlainText(value: string, limit = 3000) {
  return value.replace(/[\u0000-\u001F\u007F]/g, " ").trim().slice(0, limit);
}
