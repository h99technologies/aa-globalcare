import "server-only";
import { db } from "@/db";
import { aiConversations, aiSettings, announcements, appMigrations, auditLogs, destinations, enquiries, faqs, gallery, integrationSettings, notificationDeliveries, services, siteSettings, testimonials, userRoles } from "@/db/schema";
import { count, desc, eq } from "drizzle-orm";
import type { ControlRole } from "@/lib/auth";
import { configuredSecrets, secretStoreReady } from "@/lib/secrets";

export type ControlRow = Record<string, unknown>;
export type ControlData = {
  counts: { newEnquiries: number; totalEnquiries: number; activeServices: number; destinations: number; failedNotifications: number };
  collections: Record<"services" | "destinations" | "faqs" | "testimonials" | "gallery" | "announcements", ControlRow[]>;
  settings: ControlRow | null; integrations: ControlRow | null; ai: ControlRow | null;
  roles: ControlRow[]; recentEnquiries: ControlRow[]; deliveries: ControlRow[];
  audits: ControlRow[]; conversations: ControlRow[];
  migrationVersion: string; diagnostics: Record<string, string>;
  secretStatus: Record<string, boolean>; secretStoreReady: boolean;
};
const rows = (list: unknown[]) => list.map((item) => item as ControlRow);

export async function loadControlData(role: ControlRole): Promise<ControlData> {
  const [site, integration, ai, serviceRows, destinationRows, faqRows, testimonialRows, galleryRows, announcementRows,
    enquiryRows, total, fresh, active, visible, failed, deliveryRows, conversationRows, auditRows, migrationRows, roleRows, secrets] = await Promise.all([
    db.select().from(siteSettings).where(eq(siteSettings.id, 1)).limit(1),
    db.select().from(integrationSettings).where(eq(integrationSettings.id, 1)).limit(1),
    role === "developer" ? db.select().from(aiSettings).where(eq(aiSettings.id, 1)).limit(1) : Promise.resolve([]),
    db.select().from(services).orderBy(services.sortOrder),
    db.select().from(destinations).orderBy(destinations.sortOrder),
    db.select().from(faqs).orderBy(faqs.sortOrder),
    db.select().from(testimonials).orderBy(testimonials.sortOrder),
    db.select().from(gallery).orderBy(gallery.sortOrder),
    db.select().from(announcements).orderBy(desc(announcements.createdAt)),
    db.select().from(enquiries).orderBy(desc(enquiries.createdAt)).limit(10),
    db.select({ value: count() }).from(enquiries),
    db.select({ value: count() }).from(enquiries).where(eq(enquiries.status, "new")),
    db.select({ value: count() }).from(services).where(eq(services.active, true)),
    db.select({ value: count() }).from(destinations).where(eq(destinations.visible, true)),
    db.select({ value: count() }).from(notificationDeliveries).where(eq(notificationDeliveries.status, "failed")),
    db.select().from(notificationDeliveries).orderBy(desc(notificationDeliveries.createdAt)).limit(40),
    db.select().from(aiConversations).orderBy(desc(aiConversations.createdAt)).limit(40),
    db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(40),
    db.select().from(appMigrations).orderBy(desc(appMigrations.appliedAt)).limit(1),
    role === "developer" ? db.select().from(userRoles).orderBy(desc(userRoles.createdAt)) : Promise.resolve([]),
    role === "developer" ? configuredSecrets() : Promise.resolve({} as Record<string, boolean>),
  ]);
  return {
    counts: { newEnquiries: Number(fresh[0]?.value || 0), totalEnquiries: Number(total[0]?.value || 0),
      activeServices: Number(active[0]?.value || 0), destinations: Number(visible[0]?.value || 0), failedNotifications: Number(failed[0]?.value || 0) },
    collections: { services: rows(serviceRows), destinations: rows(destinationRows), faqs: rows(faqRows),
      testimonials: rows(testimonialRows), gallery: rows(galleryRows), announcements: rows(announcementRows) },
    settings: site[0] as ControlRow || null, integrations: integration[0] as ControlRow || null,
    ai: role === "developer" ? (ai[0] as ControlRow || null) : null,
    roles: rows(roleRows), recentEnquiries: rows(enquiryRows), deliveries: rows(deliveryRows),
    audits: rows(auditRows), conversations: rows(conversationRows),
    migrationVersion: migrationRows[0]?.version || "Not applied",
    secretStatus: secrets, secretStoreReady: role === "developer" && secretStoreReady(),
    diagnostics: role === "developer" ? {
      database: "Connected", supabaseAuth: process.env.SUPABASE_URL && process.env.SUPABASE_PUBLISHABLE_KEY ? "Configured" : "Not configured",
      supabaseAdmin: process.env.SUPABASE_SECRET_KEY ? "Configured · untested" : "Not configured",
      xAI: secrets.XAI_API_KEY ? "Configured · untested" : "Not configured",
      groq: secrets.GROQ_API_KEY ? "Configured · untested" : "Not configured",
      brevo: secrets.BREVO_API_KEY ? "Configured · untested" : "Not configured",
      telegram: secrets.TELEGRAM_BOT_TOKEN && secrets.TELEGRAM_CHAT_ID ? "Configured · untested" : "Not configured",
      publicSiteUrl: process.env.PUBLIC_SITE_URL ? "Configured" : "Not configured",
    } : {},
  };
}
