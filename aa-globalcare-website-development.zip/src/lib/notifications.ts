import "server-only";
import { db } from "@/db";
import { enquiries, integrationSettings, notificationDeliveries } from "@/db/schema";
import { and, eq, inArray, sql } from "drizzle-orm";
import { getSecret } from "@/lib/secrets";

type Enquiry = typeof enquiries.$inferSelect;
type Integration = typeof integrationSettings.$inferSelect;
type Channel = "brevo" | "telegram";

async function sendBrevo(enquiry: Enquiry, settings: Integration, key: string) {
  const response = await fetch("https://api.brevo.com/v3/smtp/email", {
    method: "POST", signal: AbortSignal.timeout(7000),
    headers: { "api-key": key, "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ sender: { name: settings.brevoSenderName, email: settings.brevoSenderEmail },
      to: [{ email: settings.notificationEmail }], subject: "New website enquiry | A&A Globalcare",
      textContent: `A new enquiry has been submitted.\nReference: ${enquiry.id}\nService: ${enquiry.service}\nSign in to your private control panel to review and respond.`,
    }),
  });
  if (!response.ok) throw new Error(`Provider HTTP ${response.status}`);
}
async function sendTelegram(enquiry: Enquiry, token: string, chatId: string) {
  const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST", signal: AbortSignal.timeout(7000), headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text: `New A&A Globalcare enquiry\nReference: ${enquiry.id}\nService: ${enquiry.service}\nSign in to the private control panel to review.`, disable_web_page_preview: true }),
  });
  if (!response.ok) throw new Error(`Provider HTTP ${response.status}`);
  const data = await response.json();
  if (!data.ok) throw new Error("Provider refused notification");
}

export async function deliverNotifications(enquiry: Enquiry, settings: Integration, retry = false) {
  const [brevoKey, telegramToken, telegramChat] = await Promise.all([getSecret("BREVO_API_KEY"), getSecret("TELEGRAM_BOT_TOKEN"), getSecret("TELEGRAM_CHAT_ID")]);
  await Promise.all((["brevo", "telegram"] as const).map(async (channel: Channel) => {
    const ready = channel === "brevo" ? !!(settings.brevoEnabled && settings.brevoSenderName && settings.brevoSenderEmail && settings.notificationEmail && brevoKey)
      : !!(settings.telegramEnabled && telegramToken && telegramChat);
    let log: { id: string } | undefined;
    if (retry) {
      if (!ready) return;
      [log] = await db.update(notificationDeliveries).set({ status: "pending", lastError: null })
        .where(and(eq(notificationDeliveries.enquiryId, enquiry.id), eq(notificationDeliveries.channel, channel), inArray(notificationDeliveries.status, ["failed", "not_configured"])))
        .returning({ id: notificationDeliveries.id });
    } else {
      [log] = await db.insert(notificationDeliveries).values({ enquiryId: enquiry.id, channel,
        status: ready ? "pending" : "not_configured", lastError: ready ? null : "Not configured" })
        .onConflictDoNothing().returning({ id: notificationDeliveries.id });
    }
    if (!log || !ready) return;
    try {
      if (channel === "brevo") await sendBrevo(enquiry, settings, brevoKey!);
      else await sendTelegram(enquiry, telegramToken!, telegramChat!);
      await db.update(notificationDeliveries).set({ status: "sent", attempts: sql`${notificationDeliveries.attempts} + 1`, lastError: null }).where(eq(notificationDeliveries.id, log.id));
    } catch (error) {
      const message = error instanceof Error && /^Provider HTTP \d{3}$/.test(error.message) ? error.message : "Provider unavailable or timed out";
      await db.update(notificationDeliveries).set({ status: "failed", attempts: sql`${notificationDeliveries.attempts} + 1`, lastError: message }).where(eq(notificationDeliveries.id, log.id));
    }
  }));
}
