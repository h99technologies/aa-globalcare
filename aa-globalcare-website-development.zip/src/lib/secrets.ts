import "server-only";
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { db } from "@/db";
import { encryptedSecrets } from "@/db/schema";
import { eq } from "drizzle-orm";

export const secretNames = ["XAI_API_KEY", "GROQ_API_KEY", "BREVO_API_KEY", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID"] as const;
export type SecretName = typeof secretNames[number];
export function secretStoreReady() { return !!keyBytes(); }
function keyBytes() {
  const encoded = process.env.CONTROL_ENCRYPTION_KEY;
  if (!encoded) return null;
  const key = Buffer.from(encoded, "base64");
  return key.length === 32 ? key : null;
}
export async function getSecret(name: SecretName): Promise<string | null> {
  const fromEnv = process.env[name];
  if (fromEnv) return fromEnv;
  const key = keyBytes();
  if (!key) return null;
  try {
    const [stored] = await db.select().from(encryptedSecrets).where(eq(encryptedSecrets.name, name)).limit(1);
    if (!stored) return null;
    const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(stored.iv, "base64"));
    decipher.setAuthTag(Buffer.from(stored.tag, "base64"));
    return Buffer.concat([decipher.update(Buffer.from(stored.ciphertext, "base64")), decipher.final()]).toString("utf8");
  } catch { return null; }
}
export async function saveSecret(name: SecretName, value: string) {
  const key = keyBytes();
  if (!key) throw new Error("Secret storage is not configured");
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
  await db.insert(encryptedSecrets).values({ name, ciphertext: encrypted.toString("base64"), iv: iv.toString("base64"), tag: cipher.getAuthTag().toString("base64") })
    .onConflictDoUpdate({ target: encryptedSecrets.name, set: { ciphertext: encrypted.toString("base64"), iv: iv.toString("base64"), tag: cipher.getAuthTag().toString("base64") } });
}
export async function removeSecret(name: SecretName) { await db.delete(encryptedSecrets).where(eq(encryptedSecrets.name, name)); }
export async function configuredSecrets(): Promise<Record<SecretName, boolean>> {
  const stored = await db.select({ name: encryptedSecrets.name }).from(encryptedSecrets);
  return Object.fromEntries(secretNames.map((name) => [name, !!process.env[name] || (secretStoreReady() && stored.some((s) => s.name === name))])) as Record<SecretName, boolean>;
}
