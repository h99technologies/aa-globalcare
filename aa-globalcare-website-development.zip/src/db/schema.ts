import { pgTable, uuid, text, integer, boolean, timestamp, jsonb, index, uniqueIndex } from "drizzle-orm/pg-core";

const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();
const updatedAt = () => timestamp("updated_at", { withTimezone: true }).notNull().defaultNow();

export const siteSettings = pgTable("site_settings", {
  id: integer("id").primaryKey().default(1),
  brandName: text("brand_name").notNull(),
  heroHeadline: text("hero_headline").notNull(),
  heroSubheadline: text("hero_subheadline").notNull(),
  introduction: text("introduction").notNull(),
  address: text("address").notNull(),
  addressConfirmed: boolean("address_confirmed").notNull().default(false),
  phonePrimary: text("phone_primary").notNull(),
  phoneSecondary: text("phone_secondary").notNull(),
  publicEmail: text("public_email"),
  whatsapp: text("whatsapp"),
  mapUrl: text("map_url"),
  support24hConfirmed: boolean("support_24h_confirmed").notNull().default(false),
  siteStatus: text("site_status", { enum: ["live", "maintenance", "suspended"] }).notNull().default("live"),
  statusMessage: text("status_message").notNull(),
  disclaimer: text("disclaimer").notNull(),
  privacyBody: text("privacy_body").notNull(),
  termsBody: text("terms_body").notNull(),
  seoTitle: text("seo_title").notNull(),
  seoDescription: text("seo_description").notNull(),
  sectionOrder: jsonb("section_order").$type<string[]>().notNull().default([]),
  createdAt: createdAt(), updatedAt: updatedAt(),
});

export const services = pgTable("services", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: text("slug").notNull().unique(), title: text("title").notNull(),
  summary: text("summary").notNull(), body: text("body").notNull(),
  includes: jsonb("includes").$type<string[]>().notNull().default([]),
  imageKey: text("image_key").notNull(), videoKey: text("video_key").notNull(),
  sortOrder: integer("sort_order").notNull().default(0), active: boolean("active").notNull().default(true),
  seoTitle: text("seo_title"), seoDescription: text("seo_description"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("services_order_idx").on(t.active, t.sortOrder)]);

export const destinations = pgTable("destinations", {
  id: uuid("id").primaryKey().defaultRandom(), country: text("country").notNull(),
  slug: text("slug").notNull().unique(), summary: text("summary").notNull(),
  serviceNotes: text("service_notes").notNull(), imageKey: text("image_key").notNull(),
  videoKey: text("video_key").notNull().default("cities"),
  visible: boolean("visible").notNull().default(true), sortOrder: integer("sort_order").notNull().default(0),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("destinations_order_idx").on(t.visible, t.sortOrder)]);

export const faqs = pgTable("faqs", {
  id: uuid("id").primaryKey().defaultRandom(), question: text("question").notNull(),
  answer: text("answer").notNull(), category: text("category").notNull().default("General"),
  sortOrder: integer("sort_order").notNull().default(0), published: boolean("published").notNull().default(false),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("faqs_order_idx").on(t.published, t.sortOrder)]);

export const testimonials = pgTable("testimonials", {
  id: uuid("id").primaryKey().defaultRandom(), quote: text("quote").notNull(),
  displayName: text("display_name").notNull(), roleLocation: text("role_location"),
  consented: boolean("consented").notNull().default(false),
  status: text("status", { enum: ["pending", "approved", "rejected"] }).notNull().default("pending"),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("testimonials_status_idx").on(t.status, t.sortOrder)]);

export const gallery = pgTable("gallery", {
  id: uuid("id").primaryKey().defaultRandom(), title: text("title").notNull(),
  assetUrl: text("asset_url").notNull(), alt: text("alt").notNull(),
  category: text("category").notNull().default("travel"), sortOrder: integer("sort_order").notNull().default(0),
  visible: boolean("visible").notNull().default(false), createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("gallery_order_idx").on(t.visible, t.sortOrder)]);

export const announcements = pgTable("announcements", {
  id: uuid("id").primaryKey().defaultRandom(), title: text("title").notNull(), body: text("body").notNull(),
  startsAt: timestamp("starts_at", { withTimezone: true }), endsAt: timestamp("ends_at", { withTimezone: true }),
  status: text("status", { enum: ["draft", "published"] }).notNull().default("draft"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("announcements_window_idx").on(t.status, t.startsAt, t.endsAt)]);

export const enquiries = pgTable("enquiries", {
  id: uuid("id").primaryKey().defaultRandom(), fullName: text("full_name").notNull(),
  email: text("email").notNull(), phone: text("phone").notNull(),
  service: text("service").notNull(), destination: text("destination"),
  message: text("message").notNull(), attachmentMetadata: jsonb("attachment_metadata").$type<Record<string, string> | null>(),
  consentAt: timestamp("consent_at", { withTimezone: true }).notNull(),
  status: text("status", { enum: ["new", "contacted", "resolved"] }).notNull().default("new"),
  privateNotes: text("private_notes").notNull().default(""),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [index("enquiries_status_created_idx").on(t.status, t.createdAt)]);

export const userRoles = pgTable("user_roles", {
  userId: uuid("user_id").primaryKey(), role: text("role", { enum: ["admin", "developer"] }).notNull(),
  createdAt: createdAt(), updatedAt: updatedAt(),
});

export const aiSettings = pgTable("ai_settings", {
  id: integer("id").primaryKey().default(1),
  provider: text("provider", { enum: ["disabled", "xai", "groq"] }).notNull().default("disabled"),
  model: text("model").notNull().default(""), enabled: boolean("enabled").notNull().default(false),
  additionalGuidance: text("additional_guidance").notNull().default(""),
  retentionDays: integer("retention_days").notNull().default(30),
  updatedAt: updatedAt(),
});

export const integrationSettings = pgTable("integration_settings", {
  id: integer("id").primaryKey().default(1),
  brevoEnabled: boolean("brevo_enabled").notNull().default(false),
  brevoSenderName: text("brevo_sender_name"), brevoSenderEmail: text("brevo_sender_email"),
  notificationEmail: text("notification_email"),
  telegramEnabled: boolean("telegram_enabled").notNull().default(false),
  whatsappVerified: boolean("whatsapp_verified").notNull().default(false),
  updatedAt: updatedAt(),
});

export const auditLogs = pgTable("audit_logs", {
  id: uuid("id").primaryKey().defaultRandom(), actorUserId: uuid("actor_user_id"),
  action: text("action").notNull(), targetType: text("target_type").notNull(), targetId: text("target_id"),
  safeMetadata: jsonb("safe_metadata").$type<Record<string, string | number | boolean>>().notNull().default({}),
  createdAt: createdAt(),
}, (t) => [index("audit_logs_created_idx").on(t.createdAt)]);

export const notificationDeliveries = pgTable("notification_deliveries", {
  id: uuid("id").primaryKey().defaultRandom(), enquiryId: uuid("enquiry_id").notNull().references(() => enquiries.id, { onDelete: "cascade" }),
  channel: text("channel", { enum: ["brevo", "telegram"] }).notNull(),
  status: text("status", { enum: ["pending", "sent", "failed", "not_configured"] }).notNull().default("pending"),
  attempts: integer("attempts").notNull().default(0), lastError: text("last_error"),
  createdAt: createdAt(), updatedAt: updatedAt(),
}, (t) => [uniqueIndex("notification_enquiry_channel_idx").on(t.enquiryId, t.channel)]);

export const aiConversations = pgTable("ai_conversations", {
  id: uuid("id").primaryKey().defaultRandom(), sessionId: text("session_id").notNull(),
  question: text("question").notNull(), answer: text("answer").notNull(),
  consentAt: timestamp("consent_at", { withTimezone: true }).notNull(), createdAt: createdAt(),
}, (t) => [index("ai_conversations_created_idx").on(t.createdAt)]);

export const rateLimits = pgTable("rate_limits", {
  key: text("key").primaryKey(), count: integer("count").notNull().default(0),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const appMigrations = pgTable("app_migrations", {
  version: text("version").primaryKey(), appliedAt: createdAt(),
});

export const encryptedSecrets = pgTable("encrypted_secrets", {
  name: text("name").primaryKey(), ciphertext: text("ciphertext").notNull(),
  iv: text("iv").notNull(), tag: text("tag").notNull(), updatedAt: updatedAt(),
});
