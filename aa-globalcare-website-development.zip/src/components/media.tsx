"use client";

import { useEffect, useRef, useState } from "react";
import { type ImageAsset, type VideoAsset, logoUrl } from "@/lib/assets";

export function SafeImage({ asset, className = "", alt, eager = false, sizes }: {
  asset: ImageAsset; className?: string; alt?: string; eager?: boolean; sizes?: string;
}) {
  const [source, setSource] = useState(asset.url);
  return <img src={source} alt={alt ?? asset.alt} className={className} width={1200} height={800}
    style={{ backgroundImage: `url('${asset.fallback}')`, backgroundSize: "cover", backgroundPosition: "center" }}
    loading={eager ? "eager" : "lazy"} decoding="async" sizes={sizes}
    onError={() => { if (source !== asset.fallback) setSource(asset.fallback); }} />;
}

export function BrandLogo({ light = false, compact = false }: { light?: boolean; compact?: boolean }) {
  const [failed, setFailed] = useState(false);
  return <span className={`brand-lockup ${light ? "brand-light" : ""} ${compact ? "brand-compact" : ""}`}>
    {failed ? <span className="brand-monogram" aria-hidden="true">A<span>&</span>A</span> :
      <img className="brand-image" src={logoUrl} alt="A&A Globalcare Consultant Ltd. logo"
        width={66} height={66} onError={() => setFailed(true)} />}
    <span className="brand-wordmark" aria-hidden={!failed ? "true" : undefined}>
      <strong>A&A <span>GLOBALCARE</span></strong><small>CONSULTANT LTD.</small>
    </span>
  </span>;
}

type ConnectionInfo = { saveData?: boolean; effectiveType?: string };
function shouldLimitMotion() {
  if (typeof window === "undefined") return true;
  const connection = (navigator as Navigator & { connection?: ConnectionInfo }).connection;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches || !!connection?.saveData ||
    (connection?.effectiveType ? ["slow-2g", "2g"].includes(connection.effectiveType) : false);
}

export function CinematicVideo({ asset, className = "", hero = false, overlay = false }: {
  asset: VideoAsset; className?: string; hero?: boolean; overlay?: boolean;
}) {
  const frameRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [allowed, setAllowed] = useState(false);
  const [near, setNear] = useState(false);
  const [visible, setVisible] = useState(hero);
  const [frameReady, setFrameReady] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setAllowed(!shouldLimitMotion());
    update();
    motion.addEventListener("change", update);
    return () => motion.removeEventListener("change", update);
  }, []);
  useEffect(() => {
    const element = frameRef.current;
    if (!element || !allowed) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) setNear(true);
      setVisible(entry.isIntersecting);
    }, { rootMargin: hero ? "0px" : "350px 0px", threshold: 0.01 });
    observer.observe(element);
    return () => observer.disconnect();
  }, [allowed, hero]);
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = true;
    video.defaultMuted = true;
    const sync = () => {
      if (allowed && visible && !document.hidden && !failed) {
        video.muted = true;
        video.play().catch(() => { setFailed(true); });
      } else video.pause();
    };
    sync();
    document.addEventListener("visibilitychange", sync);
    return () => { document.removeEventListener("visibilitychange", sync); video.pause(); };
  }, [allowed, visible, near, failed]);

  const load = allowed && (hero || near) && !failed;
  return <div ref={frameRef} className={`cinematic-video ${className}`} style={{ backgroundImage: `url('${asset.poster}')` }}>
    {load && <video ref={videoRef} className={frameReady ? "video-ready" : ""} autoPlay muted loop playsInline
      preload={hero ? "auto" : "metadata"} poster={asset.poster} aria-hidden="true" tabIndex={-1}
      onLoadedData={() => setFrameReady(true)} onError={() => setFailed(true)}>
      <source src={asset.url} type="video/mp4" />
    </video>}
    {overlay && <span className="video-overlay" aria-hidden="true" />}
  </div>;
}
