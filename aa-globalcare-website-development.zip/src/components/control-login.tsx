"use client";
import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, ArrowRight, LoaderCircle, LockKeyhole, ShieldCheck } from "lucide-react";
import { BrandLogo } from "@/components/media";

export function ControlLogin({ configured }: { configured: boolean }) {
  const router = useRouter();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false); const [error, setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault(); if (!configured) return;
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/control/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, password }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Sign in is temporarily unavailable.");
      router.push("/control/desk"); router.refresh();
    } catch (err) { setError(err instanceof Error ? err.message : "Please try again."); setBusy(false); }
  }
  return <main className="control-login-page"><div className="control-login-left"><div className="control-login-orbit" /><div className="control-login-brand"><Link href="/" aria-label="A&A Globalcare home"><BrandLogo light /></Link></div><div className="control-login-story"><span className="eyebrow eyebrow-light"><span className="eyebrow-line" /> THE PRIVATE SIDE OF THE JOURNEY</span><h1>Every detail.<br /><em>In good hands.</em></h1><p>A dedicated space to keep the content, conversations and decisions behind A&A Globalcare thoughtfully organised.</p></div><span className="control-login-bottom">A&A GLOBALCARE / PRIVATE CONTROL</span></div><div className="control-login-right"><div className="control-login-card"><div className="control-login-icon"><LockKeyhole size={23} /></div><span className="control-overline">AUTHORised ACCESS ONLY</span><h2>Welcome back.</h2><p>Sign in with your authorised account to continue.</p>{!configured && <div className="control-setup-note" role="status"><ShieldCheck size={18} /><span>Private authentication is not configured yet. Set the Supabase URL and publishable key privately before using this area.</span></div>}<form onSubmit={submit}><label htmlFor="control-email">Email address</label><input id="control-email" type="email" autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Your account email" required disabled={!configured || busy} /><label htmlFor="control-password">Password</label><input id="control-password" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Your password" required disabled={!configured || busy} />{error && <p className="control-error" role="alert">{error}</p>}<button className="button button-blue" type="submit" disabled={!configured || busy}>{busy ? <>Signing in <LoaderCircle className="spin" size={18} /></> : <>Sign in securely <ArrowRight size={18} /></>}</button></form><div className="control-login-note"><ShieldCheck size={15} /> Access is limited to approved Admin and Developer accounts.</div><Link href="/" className="control-back"><ArrowLeft size={15} /> Back to the website</Link></div></div></main>;
}
