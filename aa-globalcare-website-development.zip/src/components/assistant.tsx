"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import { ArrowUp, Bot, LoaderCircle, Phone, Sparkles, X } from "lucide-react";
import type { PublicSettings } from "@/lib/content";
import { telHref } from "@/components/site-chrome";

type Message = { who: "assistant" | "visitor"; text: string };
export function AssistantWidget({ settings }: { settings: PublicSettings }) {
  const [open, setOpen] = useState(false);
  const [question, setQuestion] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [busy, setBusy] = useState(false);
  const [consent, setConsent] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const sessionId = useRef<string>("");
  useEffect(() => { if (open) inputRef.current?.focus(); }, [open]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" }); }, [messages]);
  useEffect(() => { const key = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); }; document.addEventListener("keydown", key); return () => document.removeEventListener("keydown", key); }, []);
  async function send(e?: FormEvent) {
    e?.preventDefault();
    const text = question.trim();
    if (!text || busy) return;
    setMessages((prev) => [...prev, { who: "visitor", text }]); setQuestion(""); setBusy(true);
    if (!sessionId.current) sessionId.current = crypto.randomUUID();
    try {
      const response = await fetch("/api/assistant", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ question: text, consent, sessionId: sessionId.current }) });
      const result = await response.json();
      setMessages((prev) => [...prev, { who: "assistant", text: result.reply || "I can't confirm that from our approved information. Please speak with our team." }]);
    } catch {
      setMessages((prev) => [...prev, { who: "assistant", text: "I can't connect right now. Please call our team using the numbers below." }]);
    } finally { setBusy(false); }
  }
  return <div className="assistant-widget">
    {open && <section className="assistant-panel" role="dialog" aria-label="A&A Globalcare AI Assistant" aria-modal="false">
      <div className="assistant-head"><div className="assistant-avatar"><Bot size={21} /></div><div><strong>A&A Globalcare AI Assistant</strong><span>AI guidance · not a human consultant</span></div><button type="button" aria-label="Close assistant" onClick={() => setOpen(false)}><X size={19} /></button></div>
      <div className="assistant-messages" aria-live="polite" aria-relevant="additions text">
        <div className="assistant-welcome"><span className="assistant-spark"><Sparkles size={18} /></span><h3>How can I help you explore?</h3><p>I can share approved information about our services and next steps. For specific requirements, please check with our team.</p></div>
        {messages.map((m, i) => <div key={i} className={`assistant-message ${m.who === "visitor" ? "visitor-message" : "ai-message"}`}>{m.text}</div>)}
        {busy && <div className="assistant-message ai-message"><LoaderCircle className="spin" size={17} /><span className="sr-only">Assistant is responding</span></div>}
        <div ref={bottomRef} />
      </div>
      <div className="assistant-contact"><span>Prefer a person?</span><a href={telHref(settings.phonePrimary)}><Phone size={13} /> {settings.phonePrimary}</a></div>
      <form onSubmit={send} className="assistant-form"><label className="sr-only" htmlFor="assistant-question">Ask the AI assistant</label><input ref={inputRef} id="assistant-question" value={question} maxLength={500} onChange={(e) => setQuestion(e.target.value)} placeholder="Ask a question..." /><button type="submit" aria-label="Send question" disabled={busy || !question.trim()}><ArrowUp size={18} /></button></form>
      <label className="assistant-consent"><input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} /> Allow this conversation to be stored for quality review</label>
      <p className="assistant-note">AI may be mistaken. No eligibility or outcome guarantees. Do not share sensitive documents here.</p>
    </section>}
    <button className="assistant-launch" type="button" aria-label={open ? "Close AI assistant" : "Open A&A Globalcare AI Assistant"} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X size={22} /> : <><Sparkles size={20} /><span>Ask A&A AI</span></>}</button>
  </div>;
}
