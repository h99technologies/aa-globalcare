"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowRight, Check, LoaderCircle } from "lucide-react";
import type { PublicDestination, PublicService } from "@/lib/content";

type FormValues = { fullName: string; email: string; phone: string; service: string; destination: string; message: string; consent: boolean; website: string };
const initial: FormValues = { fullName: "", email: "", phone: "", service: "", destination: "", message: "", consent: false, website: "" };

export function EnquiryForm({ services, destinations }: { services: PublicService[]; destinations: PublicDestination[] }) {
  const [values, setValues] = useState<FormValues>(initial);
  const [state, setState] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [error, setError] = useState("");
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const selectedService = params.get("service");
    const selectedDestination = params.get("destination");
    if (selectedService && services.some((s) => s.slug === selectedService)) setValues((v) => ({ ...v, service: selectedService }));
    if (selectedDestination && destinations.some((d) => d.slug === selectedDestination)) setValues((v) => ({ ...v, destination: selectedDestination }));
    const selectService = (e: Event) => setValues((v) => ({ ...v, service: (e as CustomEvent<string>).detail }));
    const selectDestination = (e: Event) => setValues((v) => ({ ...v, destination: (e as CustomEvent<string>).detail }));
    window.addEventListener("aa:service", selectService);
    window.addEventListener("aa:destination", selectDestination);
    return () => { window.removeEventListener("aa:service", selectService); window.removeEventListener("aa:destination", selectDestination); };
  }, [services, destinations]);
  const set = (field: keyof FormValues, value: string | boolean) => setValues((prev) => ({ ...prev, [field]: value }));
  const submit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault(); setError(""); setState("submitting");
    try {
      const response = await fetch("/api/enquiries", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(values) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "Please try again in a moment.");
      setState("success"); setValues(initial);
    } catch (err) { setState("error"); setError(err instanceof Error ? err.message : "We couldn't send your enquiry. Please call us instead."); }
  };
  if (state === "success") return <div className="form-success" role="status"><span className="success-icon"><Check size={28} /></span><h3>Thank you for reaching out.</h3><p>Your enquiry has been received. Our team can review your details and get back to you using the contact information you provided.</p><button type="button" className="text-link dark-link" onClick={() => setState("idle")}>Send another enquiry <ArrowRight size={17} /></button></div>;
  return <form className="enquiry-form" onSubmit={submit} noValidate={false}>
    <div className="form-heading"><span className="eyebrow eyebrow-blue"><span className="eyebrow-line" /> START A CONVERSATION</span><h3>Tell us what you&apos;re planning.</h3><p>A few details help us understand where you&apos;d like to go from here.</p></div>
    <div className="form-grid">
      <div className="field"><label htmlFor="fullName">Full name <span aria-hidden="true">*</span></label><input id="fullName" name="fullName" type="text" autoComplete="name" minLength={2} maxLength={120} required placeholder="Your full name" value={values.fullName} onChange={(e) => set("fullName", e.target.value)} /></div>
      <div className="field"><label htmlFor="email">Email address <span aria-hidden="true">*</span></label><input id="email" name="email" type="email" autoComplete="email" maxLength={254} required placeholder="you@example.com" value={values.email} onChange={(e) => set("email", e.target.value)} /></div>
      <div className="field"><label htmlFor="phone">Phone / WhatsApp contact <span aria-hidden="true">*</span></label><input id="phone" name="phone" type="tel" autoComplete="tel" minLength={7} maxLength={30} required placeholder="Include country code" value={values.phone} onChange={(e) => set("phone", e.target.value)} /></div>
      <div className="field"><label htmlFor="service">Preferred service <span aria-hidden="true">*</span></label><select id="service" name="service" required value={values.service} onChange={(e) => set("service", e.target.value)}><option value="">Select a service</option>{services.map((s) => <option key={s.id} value={s.slug}>{s.title}</option>)}<option value="not-sure">I&apos;m not sure yet</option></select></div>
      <div className="field field-wide"><label htmlFor="destination">Destination of interest <span className="optional">optional</span></label><select id="destination" name="destination" value={values.destination} onChange={(e) => set("destination", e.target.value)}><option value="">Not decided yet</option>{destinations.map((d) => <option key={d.id} value={d.slug}>{d.country}</option>)}</select></div>
      <div className="field field-wide"><label htmlFor="message">What would you like us to know? <span aria-hidden="true">*</span></label><textarea id="message" name="message" required minLength={10} maxLength={3000} rows={5} placeholder="Share a little about your plans or the questions you have..." value={values.message} onChange={(e) => set("message", e.target.value)} /></div>
    </div>
    <div className="honeypot" aria-hidden="true"><label htmlFor="website">Leave this field empty</label><input id="website" name="website" tabIndex={-1} autoComplete="off" value={values.website} onChange={(e) => set("website", e.target.value)} /></div>
    <label className="consent-label"><input type="checkbox" name="consent" checked={values.consent} required onChange={(e) => set("consent", e.target.checked)} /><span>I agree to the use of my details to respond to this enquiry, as described in the <Link href="/privacy" target="_blank">Privacy Policy</Link>. <span aria-hidden="true">*</span></span></label>
    <p className="form-reassurance">No payment details are collected. Application outcomes are never guaranteed.</p>
    {state === "error" && <p className="form-error" role="alert">{error}</p>}
    <button type="submit" className="button button-blue form-submit" disabled={state === "submitting"}>{state === "submitting" ? <>Sending enquiry <LoaderCircle className="spin" size={18} /></> : <>Send enquiry <ArrowRight size={18} /></>}</button>
  </form>;
}
