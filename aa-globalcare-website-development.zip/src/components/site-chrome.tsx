"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowDown, ArrowRight, ArrowUpRight, LockKeyhole, Menu, Phone, X } from "lucide-react";
import { BrandLogo } from "@/components/media";
import type { PublicSettings } from "@/lib/content";

const nav = [
  { label: "Home", href: "/#home" }, { label: "Services", href: "/#services" },
  { label: "Destinations", href: "/#destinations" }, { label: "Study Abroad", href: "/#study" },
  { label: "Career Opportunities", href: "/#career" }, { label: "About", href: "/#about" },
  { label: "FAQs", href: "/#faqs" }, { label: "Contact", href: "/#contact" },
];
export function telHref(phone: string) { return `tel:${phone.replace(/[^+\d]/g, "")}`; }

export function IntroOverlay() {
  const [open, setOpen] = useState(false);
  const [leaving, setLeaving] = useState(false);
  useEffect(() => {
    if (sessionStorage.getItem("aa-intro-seen") || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const show = window.setTimeout(() => setOpen(true), 0);
    const end = window.setTimeout(() => { setLeaving(true); sessionStorage.setItem("aa-intro-seen", "1"); }, 1400);
    const remove = window.setTimeout(() => setOpen(false), 1770);
    return () => { clearTimeout(show); clearTimeout(end); clearTimeout(remove); };
  }, []);
  if (!open) return null;
  const skip = () => { sessionStorage.setItem("aa-intro-seen", "1"); setLeaving(true); window.setTimeout(() => setOpen(false), 240); };
  return <div className={`intro-overlay ${leaving ? "intro-leaving" : ""}`} aria-label="Welcome to A&A Globalcare">
    <div className="intro-orbit" aria-hidden="true"><span className="intro-orbit-dot" /></div>
    <div className="intro-center"><BrandLogo light /><span className="intro-caption">A WORLD OF POSSIBILITIES AWAITS</span></div>
    <button type="button" className="intro-skip" onClick={skip}>Skip intro <ArrowRight size={14} aria-hidden="true" /></button>
  </div>;
}

export function SiteHeader({ settings, dark = false }: { settings: PublicSettings; dark?: boolean }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(dark);
  const closeRef = useRef<HTMLButtonElement>(null);
  const drawerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (dark) return;
    const handle = () => setScrolled(window.scrollY > 36);
    handle(); window.addEventListener("scroll", handle, { passive: true });
    return () => window.removeEventListener("scroll", handle);
  }, [dark]);
  useEffect(() => {
    if (!menuOpen) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
      if (e.key === "Tab" && drawerRef.current) {
        const focusable = [...drawerRef.current.querySelectorAll<HTMLElement>('a, button:not([disabled])')];
        if (!focusable.length) return;
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => { document.body.style.overflow = original; document.removeEventListener("keydown", onKey); };
  }, [menuOpen]);
  return <>
    <header className={`site-header ${scrolled || menuOpen ? "site-header-solid" : ""}`}>
      <div className="header-topline"><span>TRAVEL WELL. GO FURTHER.</span><a href={telHref(settings.phonePrimary)}><Phone size={12} /> {settings.phonePrimary}</a></div>
      <div className="header-main container-wide">
        <Link href="/#home" className="header-brand" aria-label="A&A Globalcare home" onClick={() => setMenuOpen(false)}><BrandLogo light compact /></Link>
        <nav className="desktop-nav" aria-label="Main navigation">{nav.map((item) => <Link key={item.label} href={item.href}>{item.label}</Link>)}</nav>
        <Link className="header-cta" href="/#contact">Let&apos;s talk <ArrowUpRight size={17} aria-hidden="true" /></Link>
        <button className="menu-toggle" type="button" aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={25} /> : <Menu size={25} />}
        </button>
      </div>
    </header>
    {menuOpen && <div className="mobile-nav-scrim" onClick={() => setMenuOpen(false)} aria-hidden="true" />}
    <div id="mobile-navigation" className={`mobile-nav-drawer ${menuOpen ? "mobile-nav-open" : ""}`} role={menuOpen ? "dialog" : undefined} aria-modal={menuOpen ? true : undefined} aria-label="Mobile navigation" aria-hidden={!menuOpen} ref={drawerRef}>
      <div className="drawer-top"><span>EXPLORE A&A GLOBALCARE</span><button ref={closeRef} type="button" onClick={() => setMenuOpen(false)} aria-label="Close menu"><X size={23} /></button></div>
      <nav aria-label="Mobile navigation">{nav.map((item, i) => <Link key={item.label} href={item.href} onClick={() => setMenuOpen(false)} tabIndex={menuOpen ? 0 : -1}><span className="drawer-index">0{i + 1}</span>{item.label}<ArrowUpRight size={17} /></Link>)}</nav>
      <div className="drawer-bottom"><span>Start with a conversation.</span><a href={telHref(settings.phonePrimary)} tabIndex={menuOpen ? 0 : -1}>{settings.phonePrimary} <ArrowRight size={16} /></a></div>
    </div>
  </>;
}

export function SiteFooter({ settings }: { settings: PublicSettings }) {
  return <footer className="site-footer">
    <div className="container-wide footer-main">
      <div className="footer-intro"><Link href="/#home" aria-label="Return home"><BrandLogo light /></Link><p>Clearer guidance for wherever your next chapter may lead.</p><div className="footer-contact"><a href={telHref(settings.phonePrimary)}>{settings.phonePrimary}</a><a href={telHref(settings.phoneSecondary)}>{settings.phoneSecondary}</a>{settings.publicEmail && <a href={`mailto:${settings.publicEmail}`}>{settings.publicEmail}</a>}</div></div>
      <div className="footer-column"><h3>Explore</h3><Link href="/#services">Our services</Link><Link href="/#destinations">Destinations</Link><Link href="/#study">Study abroad</Link><Link href="/#career">Career opportunities</Link><Link href="/#about">Our approach</Link></div>
      <div className="footer-column"><h3>Here to help</h3><Link href="/#faqs">FAQs</Link><Link href="/#contact">Make an enquiry</Link><Link href="/privacy">Privacy policy</Link><Link href="/terms">Terms of use</Link>{settings.whatsapp && <a href={`https://wa.me/${settings.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent("Hello A&A Globalcare, I would like to discuss my plans.")}`} target="_blank" rel="noopener noreferrer">WhatsApp <ArrowUpRight size={14} /></a>}</div>
      <div className="footer-column footer-location"><h3>Find us</h3><p>{settings.address}</p>{!settings.addressConfirmed && <small>Please call to confirm directions before visiting.</small>}{settings.addressConfirmed && settings.mapUrl && <a href={settings.mapUrl} target="_blank" rel="noopener noreferrer">View map <ArrowUpRight size={14} /></a>}</div>
    </div>
    <div className="container-wide footer-disclaimer">{settings.disclaimer}</div>
    <div className="container-wide footer-bottom"><div><span>© {new Date().getFullYear()} {settings.brandName}. All rights reserved.</span><Link className="quiet-control-link" href="/control" aria-label="Private control login" title="Private control login"><LockKeyhole size={13} strokeWidth={1.4} /></Link></div><Link href="/#home" className="back-to-top">Back to top <ArrowDown size={14} className="up-arrow" /></Link></div>
  </footer>;
}
