"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, ArrowUpRight, Bell, BookOpen, BriefcaseBusiness, Check, ChevronLeft, ChevronRight, CircleHelp, Database, FileText, Globe2, Inbox, LayoutDashboard, LoaderCircle, LockKeyhole, LogOut, MessageSquare, Plus, RefreshCw, Search, Settings2, ShieldCheck, Trash2, X } from "lucide-react";
import type { ControlUser } from "@/lib/auth";
import type { ControlData, ControlRow } from "@/lib/control-data";
import { imageLibrary, images, videos } from "@/lib/assets";
import { sectionIds } from "@/lib/content";

type Collection = keyof ControlData["collections"];
type Field = { key: string; label: string; type?: "text" | "textarea" | "number" | "checkbox" | "select" | "list" | "datetime" | "email" | "url"; options?: Array<[string, string]>; hint?: string };
const imageOptions: Array<[string, string]> = imageLibrary.map((i) => [i.id, i.title]);
const videoOptions: Array<[string, string]> = Object.values(videos).map((v) => [v.id, v.title]);
const fields: Record<Collection, Field[]> = {
  services: [
    { key: "title", label: "Service title" }, { key: "slug", label: "URL slug" },
    { key: "summary", label: "Short headline", type: "textarea" }, { key: "body", label: "Description", type: "textarea" },
    { key: "includes", label: "What it may include (one per line)", type: "list" },
    { key: "imageKey", label: "Image from supplied library", type: "select", options: imageOptions },
    { key: "videoKey", label: "Video from supplied library", type: "select", options: videoOptions },
    { key: "sortOrder", label: "Display order", type: "number" }, { key: "active", label: "Published", type: "checkbox" },
    { key: "seoTitle", label: "SEO title (optional)" }, { key: "seoDescription", label: "SEO description (optional)", type: "textarea" },
  ],
  destinations: [
    { key: "country", label: "Destination name" }, { key: "slug", label: "URL slug" },
    { key: "summary", label: "Public summary", type: "textarea" }, { key: "serviceNotes", label: "Availability caveat", type: "textarea" },
    { key: "imageKey", label: "Image", type: "select", options: imageOptions },
    { key: "videoKey", label: "Video", type: "select", options: videoOptions },
    { key: "sortOrder", label: "Display order", type: "number" }, { key: "visible", label: "Visible on website", type: "checkbox" },
  ],
  faqs: [
    { key: "question", label: "Question" }, { key: "answer", label: "Approved answer", type: "textarea" },
    { key: "category", label: "Category" }, { key: "sortOrder", label: "Display order", type: "number" },
    { key: "published", label: "Published", type: "checkbox" },
  ],
  testimonials: [
    { key: "quote", label: "Approved quotation", type: "textarea" }, { key: "displayName", label: "Approved display name" },
    { key: "roleLocation", label: "Role / location (only with consent)" },
    { key: "consented", label: "Publication consent recorded", type: "checkbox" },
    { key: "status", label: "Moderation status", type: "select", options: [["pending", "Pending"], ["approved", "Approved"], ["rejected", "Rejected"]] },
    { key: "sortOrder", label: "Display order", type: "number" },
  ],
  gallery: [
    { key: "title", label: "Image title" }, { key: "assetUrl", label: "HTTPS image URL", type: "url" },
    { key: "alt", label: "Descriptive alt text" }, { key: "category", label: "Category" },
    { key: "sortOrder", label: "Display order", type: "number" }, { key: "visible", label: "Visible on website", type: "checkbox" },
  ],
  announcements: [
    { key: "title", label: "Announcement title" }, { key: "body", label: "Approved announcement", type: "textarea" },
    { key: "startsAt", label: "Publish from (optional)", type: "datetime" }, { key: "endsAt", label: "Publish until (optional)", type: "datetime" },
    { key: "status", label: "Status", type: "select", options: [["draft", "Draft"], ["published", "Published"]] },
  ],
};
const siteFields: Field[] = [
  { key: "brandName", label: "Company name" }, { key: "heroHeadline", label: "Hero headline" },
  { key: "heroSubheadline", label: "Hero supporting copy", type: "textarea" },
  { key: "introduction", label: "Company introduction", type: "textarea" },
  { key: "address", label: "Address as supplied (confirm spelling with owner)", type: "textarea" },
  { key: "addressConfirmed", label: "Owner confirmed address and map pin", type: "checkbox" },
  { key: "phonePrimary", label: "Contact number one" }, { key: "phoneSecondary", label: "Contact number two" },
  { key: "publicEmail", label: "Verified public email (leave blank until confirmed)", type: "email" },
  { key: "whatsapp", label: "Verified WhatsApp number (Developer must enable verification)", type: "text" },
  { key: "mapUrl", label: "Verified HTTPS map link (optional)", type: "url" },
  { key: "support24hConfirmed", label: "Owner confirmed 24/7 support claim", type: "checkbox" },
  { key: "disclaimer", label: "Non-guarantee disclaimer (owner/legal review)", type: "textarea" },
  { key: "privacyBody", label: "Privacy Policy draft", type: "textarea" },
  { key: "termsBody", label: "Terms draft", type: "textarea" },
  { key: "seoTitle", label: "Homepage SEO title" }, { key: "seoDescription", label: "Homepage SEO description", type: "textarea" },
];
const collectionLabels: Record<Collection, string> = { services: "Services", destinations: "Destinations", faqs: "FAQs", testimonials: "Testimonials", gallery: "Gallery", announcements: "Announcements" };
const recordName = (row: ControlRow) => String(row.title || row.country || row.question || row.displayName || "Untitled record");
const text = (value: unknown) => value == null ? "" : String(value);
const dateText = (value: unknown) => { if (!value) return ""; const date = new Date(String(value)); return Number.isNaN(date.getTime()) ? "" : date.toISOString().slice(0, 16); };
const friendlyDate = (value: unknown) => value ? new Date(String(value)).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" }) : "—";

function FieldInput({ field, value, onChange, id }: { field: Field; value: unknown; onChange: (value: unknown) => void; id: string }) {
  const controlId = `${id}-${field.key}`;
  if (field.type === "checkbox") return <label className="desk-checkbox"><input id={controlId} type="checkbox" checked={Boolean(value)} onChange={(e) => onChange(e.target.checked)} /><span>{field.label}</span></label>;
  return <div className={`desk-field ${field.type === "textarea" || field.type === "list" ? "desk-field-wide" : ""}`}><label htmlFor={controlId}>{field.label}</label>
    {field.type === "textarea" || field.type === "list" ? <textarea id={controlId} rows={field.type === "list" ? 4 : 5} value={field.type === "list" && Array.isArray(value) ? value.join("\n") : text(value)} onChange={(e) => onChange(field.type === "list" ? e.target.value.split("\n").map((v) => v.trim()).filter(Boolean) : e.target.value)} /> :
      field.type === "select" ? <select id={controlId} value={text(value)} onChange={(e) => onChange(e.target.value)}>{field.options?.map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select> :
      <input id={controlId} type={field.type === "number" ? "number" : field.type === "datetime" ? "datetime-local" : field.type === "email" ? "email" : field.type === "url" ? "url" : "text"} value={field.type === "datetime" ? dateText(value) : text(value)} onChange={(e) => onChange(field.type === "number" ? Number(e.target.value) : e.target.value)} />}
    {field.hint && <small>{field.hint}</small>}
  </div>;
}

export function ControlDashboard({ user, initialData }: { user: ControlUser; initialData: ControlData }) {
  const [data, setData] = useState(initialData);
  const [tab, setTab] = useState("overview");
  const [collection, setCollection] = useState<Collection>("services");
  const [editing, setEditing] = useState<{ entity: Collection; id?: string } | null>(null);
  const [form, setForm] = useState<ControlRow>({});
  const [siteForm, setSiteForm] = useState<ControlRow>(initialData.settings || {});
  const [techForm, setTechForm] = useState<ControlRow>(initialData.settings || {});
  const [aiForm, setAiForm] = useState<ControlRow>(initialData.ai || {});
  const [integrationForm, setIntegrationForm] = useState<ControlRow>(initialData.integrations || {});
  const [selectedEnquiry, setSelectedEnquiry] = useState<ControlRow | null>(null);
  const [enquiryStatus, setEnquiryStatus] = useState("new");
  const [notes, setNotes] = useState("");
  const [enquiryItems, setEnquiryItems] = useState<ControlRow[]>(initialData.recentEnquiries);
  const [enquiryTotal, setEnquiryTotal] = useState(initialData.counts.totalEnquiries);
  const [page, setPage] = useState(1); const [query, setQuery] = useState(""); const [filter, setFilter] = useState("all");
  const [busy, setBusy] = useState(false); const [notice, setNotice] = useState(""); const [error, setError] = useState("");
  const [roleId, setRoleId] = useState(""); const [roleName, setRoleName] = useState<"admin" | "developer">("admin"); const [inviteEmail, setInviteEmail] = useState("");
  const [secretName, setSecretName] = useState("XAI_API_KEY"); const [secretValue, setSecretValue] = useState("");
  const developer = user.role === "developer";
  const nav = [
    ["overview", "Overview", LayoutDashboard], ["enquiries", "Enquiries", Inbox], ["content", "Content library", BookOpen],
    ["site", "Website copy", Globe2], ["operations", "Operations", Bell], ["privacy", "AI privacy", MessageSquare],
    ...(developer ? [["developer", "Developer settings", Settings2], ["roles", "Access & roles", ShieldCheck], ["diagnostics", "Diagnostics", Database]] as const : []),
  ] as const;

  useEffect(() => {
    if (tab !== "enquiries") return;
    const timer = setTimeout(async () => {
      try {
        const params = new URLSearchParams({ page: String(page), status: filter, search: query });
        const response = await fetch(`/api/control/enquiries?${params}`);
        if (!response.ok) throw new Error("Unable to load enquiries.");
        const result = await response.json(); setEnquiryItems(result.items); setEnquiryTotal(result.total);
      } catch { setError("Could not refresh enquiries. Please try again."); }
    }, 280);
    return () => clearTimeout(timer);
  }, [tab, page, filter, query]);

  async function refresh() {
    const response = await fetch("/api/control/data", { cache: "no-store" });
    if (!response.ok) throw new Error("Could not refresh dashboard data.");
    const updated: ControlData = await response.json(); setData(updated);
    setSiteForm(updated.settings || {}); setTechForm(updated.settings || {}); setAiForm(updated.ai || {}); setIntegrationForm(updated.integrations || {});
    if (tab === "enquiries") {
      const params = new URLSearchParams({ page: String(page), status: filter, search: query });
      const latest = await fetch(`/api/control/enquiries?${params}`);
      if (latest.ok) { const result = await latest.json(); setEnquiryItems(result.items); setEnquiryTotal(result.total); }
    }
  }
  async function send(url: string, payload: unknown, success = "Changes saved.") {
    setBusy(true); setNotice(""); setError("");
    try {
      const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.message || "The request could not be completed.");
      setNotice(result.message || success); await refresh(); return true;
    } catch (err) { setError(err instanceof Error ? err.message : "Please try again."); return false; }
    finally { setBusy(false); }
  }
  async function logout() { await fetch("/api/control/logout", { method: "POST" }); window.location.href = "/control"; }
  function newRecord(entity: Collection) {
    const defaults: ControlRow = { sortOrder: data.collections[entity].length + 1, active: false, visible: false, published: false,
      consented: false, status: entity === "announcements" ? "draft" : "pending", imageKey: entity === "destinations" ? "canada" : "airport",
      videoKey: entity === "destinations" ? "cities" : "airport", includes: [], category: "General", roleLocation: null, startsAt: null, endsAt: null, seoTitle: "", seoDescription: "" };
    setForm(defaults); setEditing({ entity }); setError("");
  }
  function editRecord(entity: Collection, row: ControlRow) { setForm({ ...row }); setEditing({ entity, id: text(row.id) }); setError(""); }
  async function saveRecord(e: FormEvent) {
    e.preventDefault(); if (!editing) return;
    const values: ControlRow = {};
    for (const field of fields[editing.entity]) values[field.key] = form[field.key] ?? (field.type === "checkbox" ? false : field.type === "number" ? 0 : field.type === "list" ? [] : "");
    if (editing.entity === "testimonials") values.roleLocation = text(values.roleLocation) || null;
    if (editing.entity === "announcements") { values.startsAt = values.startsAt || null; values.endsAt = values.endsAt || null; }
    const ok = await send("/api/control/content", { entity: editing.entity, action: "save", id: editing.id, data: values }, "Content saved. The public website is updated.");
    if (ok) setEditing(null);
  }
  async function deleteRecord(entity: Collection, id: string) {
    if (!window.confirm(`Permanently delete this ${collectionLabels[entity].slice(0, -1).toLowerCase()}? This cannot be undone.`)) return;
    await send("/api/control/content", { entity, action: "delete", id }, "Record deleted.");
  }
  function openEnquiry(row: ControlRow) { setSelectedEnquiry(row); setEnquiryStatus(text(row.status)); setNotes(text(row.privateNotes)); setError(""); }
  async function updateEnquiry(action: "update" | "delete") {
    if (!selectedEnquiry) return;
    if (action === "delete" && !window.confirm("Permanently delete this private enquiry and its delivery logs? This cannot be undone.")) return;
    const ok = await send("/api/control/manage", { kind: "enquiry", data: { action, id: selectedEnquiry.id, status: enquiryStatus, privateNotes: notes } }, action === "delete" ? "Enquiry deleted." : "Enquiry updated.");
    if (ok) setSelectedEnquiry(null);
  }
  const topTitle: Record<string, string> = { overview: "A clearer view of what matters.", enquiries: "Every conversation, considered.", content: "The stories you put into the world.", site: "Make every word your own.", operations: "Keep the details moving.", privacy: "Privacy, by intention.", developer: "The technical controls.", roles: "Access stays intentional.", diagnostics: "A transparent system view." };

  return <div className="desk-shell"><aside className="desk-sidebar"><Link href="/" className="desk-brand"><span className="desk-brand-mark">A&A</span><span>GLOBALCARE<small>PRIVATE CONTROL</small></span></Link><div className="desk-sidebar-label">WORKSPACE</div><nav aria-label="Dashboard sections">{nav.map(([key, label, Icon]) => <button type="button" key={key} className={tab === key ? "desk-nav-active" : ""} onClick={() => { setTab(key); setError(""); setNotice(""); }}><Icon size={17} /><span>{label}</span>{key === "enquiries" && data.counts.newEnquiries > 0 && <b>{data.counts.newEnquiries}</b>}</button>)}</nav><div className="desk-sidebar-bottom"><span className="desk-role"><span className="desk-role-dot" /> {user.role.toUpperCase()}</span><span className="desk-user-email">{user.email}</span><button type="button" onClick={logout}><LogOut size={16} /> Sign out</button></div></aside>
    <div className="desk-main"><header className="desk-topbar"><div><span className="desk-mobile-brand">A&A / CONTROL</span><span className="desk-breadcrumb">PRIVATE WORKSPACE <ChevronRight size={13} /> {tab.toUpperCase()}</span></div><div><Link href="/" target="_blank">View website <ArrowUpRight size={15} /></Link><button type="button" onClick={() => refresh().catch(() => setError("Unable to refresh dashboard."))} aria-label="Refresh dashboard"><RefreshCw size={17} /></button></div></header>
      <div className="desk-mobile-nav"><label htmlFor="desk-tab">Workspace section</label><select id="desk-tab" value={tab} onChange={(e) => setTab(e.target.value)}>{nav.map(([key, label]) => <option key={key} value={key}>{label}</option>)}</select></div>
      <main className="desk-content"><div className="desk-page-head"><span className="desk-kicker">A&A GLOBALCARE / {user.role.toUpperCase()}</span><h1>{topTitle[tab]}</h1><p>Thoughtfully managed, always grounded in real information.</p></div>
        {notice && <div className="desk-notice" role="status"><Check size={17} /> {notice}<button type="button" onClick={() => setNotice("")} aria-label="Dismiss"><X size={15} /></button></div>}
        {error && <div className="desk-error" role="alert">{error}<button type="button" onClick={() => setError("")} aria-label="Dismiss"><X size={15} /></button></div>}

        {tab === "overview" && <><div className="desk-stats"><div><span>NEW ENQUIRIES</span><strong>{data.counts.newEnquiries}</strong><small>Waiting for a response</small></div><div><span>ALL ENQUIRIES</span><strong>{data.counts.totalEnquiries}</strong><small>Stored privately</small></div><div><span>ACTIVE SERVICES</span><strong>{data.counts.activeServices}</strong><small>Live on the website</small></div><div><span>DESTINATIONS SHOWN</span><strong>{data.counts.destinations}</strong><small>Candidate entries</small></div></div><div className="desk-two-col"><section className="desk-panel"><div className="desk-panel-head"><div><span className="desk-kicker">INBOX</span><h2>Recent enquiries</h2></div><button type="button" onClick={() => setTab("enquiries")}>View all <ArrowRight size={15} /></button></div>{data.recentEnquiries.length ? data.recentEnquiries.slice(0, 6).map((row) => <button type="button" className="desk-list-row" key={text(row.id)} onClick={() => { setTab("enquiries"); openEnquiry(row); }}><span className="desk-list-icon"><Inbox size={16} /></span><span><strong>{text(row.fullName)}</strong><small>{text(row.service)} · {friendlyDate(row.createdAt)}</small></span><span className={`desk-status status-${text(row.status)}`}>{text(row.status)}</span></button>) : <div className="desk-empty">No enquiries yet. New submissions will appear here.</div>}</section><section className="desk-panel desk-overview-side"><div className="desk-panel-head"><div><span className="desk-kicker">A FEW IMPORTANT DETAILS</span><h2>Before going live</h2></div></div><ul><li>Confirm the supplied address spelling and map pin with the owner.</li><li>Confirm which destination services are currently available.</li><li>Review the draft legal wording and any 24/7 support claim.</li><li>Verify sender identity and test notifications before enabling them.</li></ul><div className="desk-overview-note"><ShieldCheck size={18} /> No approval, admission or employment outcomes are guaranteed.</div></section></div></>}

        {tab === "enquiries" && <section className="desk-panel"><div className="desk-toolbar"><div className="desk-search"><Search size={16} /><input aria-label="Search enquiries" placeholder="Search name, email or phone" value={query} onChange={(e) => { setQuery(e.target.value); setPage(1); }} /></div><select aria-label="Filter by status" value={filter} onChange={(e) => { setFilter(e.target.value); setPage(1); }}><option value="all">All statuses</option><option value="new">New</option><option value="contacted">Contacted</option><option value="resolved">Resolved</option></select></div>{enquiryItems.length ? <div className="desk-table-wrap"><table className="desk-table"><thead><tr><th>Name / email</th><th>Service</th><th>Destination</th><th>Received</th><th>Status</th><th></th></tr></thead><tbody>{enquiryItems.map((row) => <tr key={text(row.id)}><td><strong>{text(row.fullName)}</strong><small>{text(row.email)}</small></td><td>{text(row.service)}</td><td>{text(row.destination) || "Not chosen"}</td><td>{friendlyDate(row.createdAt)}</td><td><span className={`desk-status status-${text(row.status)}`}>{text(row.status)}</span></td><td><button type="button" className="desk-row-action" onClick={() => openEnquiry(row)}>Open <ArrowUpRight size={14} /></button></td></tr>)}</tbody></table></div> : <div className="desk-empty">No enquiries match this view. Try another search or status.</div>}<div className="desk-pagination"><span>{enquiryTotal} enquiries · Page {page} of {Math.max(1, Math.ceil(enquiryTotal / 10))}</span><div><button type="button" disabled={page <= 1} onClick={() => setPage(page - 1)} aria-label="Previous page"><ChevronLeft size={18} /></button><button type="button" disabled={page >= Math.ceil(enquiryTotal / 10)} onClick={() => setPage(page + 1)} aria-label="Next page"><ChevronRight size={18} /></button></div></div></section>}

        {tab === "content" && <><div className="desk-collection-tabs" aria-label="Content types">{(Object.keys(collectionLabels) as Collection[]).map((key) => <button type="button" key={key} className={collection === key ? "active" : ""} onClick={() => setCollection(key)}>{collectionLabels[key]} <small>{data.collections[key].length}</small></button>)}</div><section className="desk-panel"><div className="desk-panel-head"><div><span className="desk-kicker">EDITABLE PUBLIC CONTENT</span><h2>{collectionLabels[collection]}</h2></div><button type="button" className="desk-primary-small" onClick={() => newRecord(collection)}><Plus size={16} /> Add {collection === "faqs" ? "FAQ" : collection === "testimonials" ? "approved story" : "new"}</button></div>{collection === "testimonials" && <p className="desk-info">Testimonials remain hidden until explicitly approved and publication consent is recorded. No stories are seeded.</p>}{collection === "destinations" && <p className="desk-info">These are candidate destinations from the supplied flyer, not a guarantee of programme availability.</p>}{data.collections[collection].length ? <div className="desk-record-list">{data.collections[collection].map((row) => <div className="desk-record" key={text(row.id)}><div><strong>{recordName(row)}</strong><small>{text(row.slug) || text(row.category) || `Updated ${friendlyDate(row.updatedAt)}`}</small></div><span className={`desk-status ${row.active || row.visible || row.published || row.status === "approved" || row.status === "published" ? "status-live" : "status-draft"}`}>{row.active || row.visible || row.published || row.status === "approved" || row.status === "published" ? "Live" : text(row.status) || "Hidden"}</span><button type="button" onClick={() => editRecord(collection, row)}>Edit</button><button type="button" className="desk-danger-icon" onClick={() => deleteRecord(collection, text(row.id))} aria-label={`Delete ${recordName(row)}`}><Trash2 size={16} /></button></div>)}</div> : <div className="desk-empty">Nothing here yet. Add an approved entry to begin.</div>}</section></>}

        {tab === "site" && <section className="desk-panel desk-form-panel"><div className="desk-panel-head"><div><span className="desk-kicker">PUBLIC-FACING DETAILS</span><h2>Website copy & contact</h2></div></div><p className="desk-info">Changes appear on the public website immediately. Leave unverified email, WhatsApp and map fields blank. Confirm legal text with the company.</p><form onSubmit={async (e) => { e.preventDefault(); const values = Object.fromEntries(siteFields.map((f) => [f.key, siteForm[f.key] ?? (f.type === "checkbox" ? false : "")])); await send("/api/control/content", { entity: "site_settings", action: "save", data: values }, "Website copy updated."); }}><div className="desk-form-grid">{siteFields.map((field) => <FieldInput key={field.key} id="site" field={field} value={siteForm[field.key]} onChange={(value) => setSiteForm((v) => ({ ...v, [field.key]: value }))} />)}</div><button className="desk-save" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={17} /> : <Check size={17} />} Save website details</button></form></section>}

        {tab === "operations" && <div className="desk-two-col"><section className="desk-panel"><div className="desk-panel-head"><div><span className="desk-kicker">DELIVERY HEALTH</span><h2>Notifications</h2></div></div><p className="desk-info">An enquiry is saved even if a notification fails. Provider tests verify credentials only, not real delivery.</p><div className="desk-test-buttons"><button type="button" disabled={busy} onClick={() => send("/api/control/manage", { kind: "test", data: { channel: "brevo" } }, "Brevo credential check completed.")}>Test Brevo credential <ArrowUpRight size={15} /></button><button type="button" disabled={busy} onClick={() => send("/api/control/manage", { kind: "test", data: { channel: "telegram" } }, "Telegram credential check completed.")}>Test Telegram credential <ArrowUpRight size={15} /></button></div>{data.deliveries.length ? data.deliveries.map((row) => <div className="desk-delivery" key={text(row.id)}><span className={`desk-status status-${text(row.status)}`}>{text(row.status)}</span><div><strong>{text(row.channel)}</strong><small>Enquiry {text(row.enquiryId).slice(0, 8)} · {friendlyDate(row.createdAt)}</small>{Boolean(row.lastError) && <small>{text(row.lastError)}</small>}</div>{row.status !== "sent" && <button type="button" disabled={busy} onClick={() => send("/api/control/manage", { kind: "retry", data: { id: row.enquiryId } }, "Retry attempted. Check the updated delivery state.")}>Retry</button>}</div>) : <div className="desk-empty">No notification attempts yet. They appear after an enquiry is submitted.</div>}</section><section className="desk-panel"><div className="desk-panel-head"><div><span className="desk-kicker">GOOD PRACTICE</span><h2>Operational notes</h2></div></div><ul className="desk-plain-list"><li>Only enabled, fully configured channels receive alerts.</li><li>Brevo requires a verified sender/domain and notification destination.</li><li>Telegram requires the bot to have access to the configured private chat.</li><li>A failed provider request never removes the original enquiry.</li><li>No customer acknowledgement is sent until approved wording is configured.</li></ul></section></div>}

        {tab === "privacy" && <section className="desk-panel"><div className="desk-panel-head"><div><span className="desk-kicker">OPT-IN TRANSCRIPTS ONLY</span><h2>AI conversations</h2></div><button type="button" disabled={busy} onClick={() => send("/api/control/manage", { kind: "conversation", data: { action: "purge" } }, "Expired transcripts removed.")}>Purge expired <Trash2 size={14} /></button></div><p className="desk-info">Chats are ephemeral unless a visitor explicitly opts into storage. Stored transcripts are subject to the Developer-configured retention period.</p>{data.conversations.length ? data.conversations.map((row) => <div className="desk-conversation" key={text(row.id)}><div><strong>{text(row.question)}</strong><p>{text(row.answer)}</p><small>Consent recorded {friendlyDate(row.consentAt)}</small></div><button type="button" aria-label="Delete conversation" onClick={() => { if (window.confirm("Delete this consented AI transcript?")) send("/api/control/manage", { kind: "conversation", data: { action: "delete", id: row.id } }, "Transcript deleted."); }}><Trash2 size={16} /></button></div>) : <div className="desk-empty">No consented AI transcripts are stored.</div>}</section>}

        {tab === "developer" && developer && <div className="desk-stack"><section className="desk-panel desk-form-panel"><div className="desk-panel-head"><div><span className="desk-kicker">PUBLIC SITE STATUS</span><h2>Maintenance & section order</h2></div></div><div className="desk-form-grid"><FieldInput id="tech" field={{ key: "siteStatus", label: "Site status", type: "select", options: [["live", "Live"], ["maintenance", "Maintenance"], ["suspended", "Suspended"]] }} value={techForm.siteStatus} onChange={(v) => setTechForm((old) => ({ ...old, siteStatus: v }))} /><FieldInput id="tech" field={{ key: "statusMessage", label: "Public notice", type: "textarea" }} value={techForm.statusMessage} onChange={(v) => setTechForm((old) => ({ ...old, statusMessage: v }))} /></div><div className="desk-order"><h3>Homepage section order</h3><p>Move sections without editing source code. Core hero, trust strip and final invitation remain fixed.</p>{(Array.isArray(techForm.sectionOrder) ? techForm.sectionOrder as string[] : sectionIds).map((name, i, all) => <div key={name}><span>{String(i + 1).padStart(2, "0")} · {name.replaceAll("-", " ")}</span><button type="button" disabled={i === 0} aria-label={`Move ${name} up`} onClick={() => { const next = [...all]; [next[i - 1], next[i]] = [next[i], next[i - 1]]; setTechForm((v) => ({ ...v, sectionOrder: next })); }}><ArrowUp size={15} /></button><button type="button" disabled={i === all.length - 1} aria-label={`Move ${name} down`} onClick={() => { const next = [...all]; [next[i + 1], next[i]] = [next[i], next[i + 1]]; setTechForm((v) => ({ ...v, sectionOrder: next })); }}><ArrowDown size={15} /></button></div>)}</div><button className="desk-save" type="button" disabled={busy} onClick={() => send("/api/control/manage", { kind: "site", data: { siteStatus: techForm.siteStatus, statusMessage: techForm.statusMessage, sectionOrder: techForm.sectionOrder } }, "Site status and order saved.")}>Save site controls <Check size={16} /></button></section>
          <section className="desk-panel desk-form-panel"><div className="desk-panel-head"><div><span className="desk-kicker">AI CONSULTANT</span><h2>Provider & retention</h2></div></div><p className="desk-info">xAI and Groq are separate providers. Enabling either without a configured key leaves the assistant in a friendly fallback state. Guidance must be owner-approved.</p><div className="desk-form-grid">{[
            { key: "provider", label: "Provider", type: "select" as const, options: [["disabled", "Disabled"], ["xai", "xAI (Grok)"], ["groq", "Groq Cloud"]] as Array<[string, string]> },
            { key: "model", label: "Provider model ID" }, { key: "retentionDays", label: "Consented transcript retention (days)", type: "number" as const },
            { key: "additionalGuidance", label: "Approved additional guidance (no secrets)", type: "textarea" as const },
            { key: "enabled", label: "Enable AI assistant", type: "checkbox" as const },
          ].map((field) => <FieldInput key={field.key} id="ai" field={field} value={aiForm[field.key]} onChange={(v) => setAiForm((old) => ({ ...old, [field.key]: v }))} />)}</div><button className="desk-save" type="button" disabled={busy} onClick={() => send("/api/control/manage", { kind: "ai", data: { provider: aiForm.provider || "disabled", model: aiForm.model || "", retentionDays: aiForm.retentionDays || 30, additionalGuidance: aiForm.additionalGuidance || "", enabled: Boolean(aiForm.enabled) } }, "AI settings saved.")}>Save AI settings <Check size={16} /></button></section>
          <section className="desk-panel desk-form-panel"><div className="desk-panel-head"><div><span className="desk-kicker">NON-SECRET PROVIDER SETTINGS</span><h2>Integration details</h2></div></div><div className="desk-form-grid">{[
            { key: "brevoSenderName", label: "Brevo sender name" }, { key: "brevoSenderEmail", label: "Verified Brevo sender email", type: "email" as const },
            { key: "notificationEmail", label: "Private alert recipient email", type: "email" as const },
            { key: "brevoEnabled", label: "Enable Brevo enquiry alerts", type: "checkbox" as const },
            { key: "telegramEnabled", label: "Enable Telegram enquiry alerts", type: "checkbox" as const },
            { key: "whatsappVerified", label: "Owner verified the public WhatsApp number", type: "checkbox" as const },
          ].map((field) => <FieldInput key={field.key} id="integration" field={field} value={integrationForm[field.key]} onChange={(v) => setIntegrationForm((old) => ({ ...old, [field.key]: v }))} />)}</div><button className="desk-save" type="button" disabled={busy} onClick={() => send("/api/control/manage", { kind: "integrations", data: { brevoSenderName: integrationForm.brevoSenderName || "", brevoSenderEmail: integrationForm.brevoSenderEmail || "", notificationEmail: integrationForm.notificationEmail || "", brevoEnabled: Boolean(integrationForm.brevoEnabled), telegramEnabled: Boolean(integrationForm.telegramEnabled), whatsappVerified: Boolean(integrationForm.whatsappVerified) } }, "Integration details saved.")}>Save integration details <Check size={16} /></button></section>
          <section className="desk-panel desk-form-panel"><div className="desk-panel-head"><div><span className="desk-kicker">SERVER-SIDE ONLY</span><h2>Encrypted credentials</h2></div></div><p className="desk-info">Credentials are encrypted at rest with a separate deployment key. Values are write-only here, never retrieved into the browser. Deployment environment values take precedence over stored values.</p><div className="desk-secret-status">{["XAI_API_KEY", "GROQ_API_KEY", "BREVO_API_KEY", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID"].map((name) => <div key={name}><span>{name}</span><strong>{data.secretStatus[name] ? "•••••••• · configured" : "Not configured"}</strong></div>)}</div>{!data.secretStoreReady && <p className="desk-warning">Secret entry is disabled until CONTROL_ENCRYPTION_KEY is set privately in deployment secrets.</p>}<div className="desk-form-grid"><div className="desk-field"><label htmlFor="secret-name">Credential</label><select id="secret-name" value={secretName} onChange={(e) => setSecretName(e.target.value)}>{["XAI_API_KEY", "GROQ_API_KEY", "BREVO_API_KEY", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID"].map((n) => <option key={n}>{n}</option>)}</select></div><div className="desk-field"><label htmlFor="secret-value">New value (never shown again)</label><input id="secret-value" type="password" autoComplete="off" value={secretValue} onChange={(e) => setSecretValue(e.target.value)} placeholder="Enter a rotated credential" disabled={!data.secretStoreReady} /></div></div><div className="desk-button-row"><button type="button" className="desk-save" disabled={busy || !data.secretStoreReady || secretValue.length < 10} onClick={async () => { const ok = await send("/api/control/manage", { kind: "secret", data: { name: secretName, action: "set", value: secretValue } }, "Credential stored securely."); if (ok) setSecretValue(""); }}>Store credential <LockKeyhole size={16} /></button><button type="button" disabled={busy || !data.secretStoreReady} onClick={() => { if (window.confirm(`Remove stored ${secretName}? A deployment environment value, if set, will still apply.`)) send("/api/control/manage", { kind: "secret", data: { name: secretName, action: "remove" } }, "Stored credential removed."); }}>Remove stored value</button></div></section></div>}

        {tab === "roles" && developer && <div className="desk-two-col"><section className="desk-panel desk-form-panel"><div className="desk-panel-head"><div><span className="desk-kicker">DEVELOPER ONLY</span><h2>Admin & Developer accounts</h2></div></div><p className="desk-info">Create the first Developer in Supabase Auth and bootstrap its UUID by private SQL. For existing users, grant a role using the Supabase Auth user UUID. There is no Staff role.</p>{data.roles.length ? data.roles.map((row) => <div className="desk-role-record" key={text(row.userId)}><div><strong>{text(row.role)}</strong><small>{text(row.userId)}</small></div><button type="button" onClick={() => { if (window.confirm("Revoke this account's control access?")) send("/api/control/manage", { kind: "role", data: { action: "revoke", userId: row.userId } }, "Role revoked."); }}>Revoke</button></div>) : <div className="desk-empty">No roles found. Bootstrap the first Developer with private SQL.</div>}<div className="desk-field"><label htmlFor="role-uuid">Existing Supabase Auth user UUID</label><input id="role-uuid" value={roleId} onChange={(e) => setRoleId(e.target.value)} placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" /></div><div className="desk-field"><label htmlFor="role-name">Role</label><select id="role-name" value={roleName} onChange={(e) => setRoleName(e.target.value as "admin" | "developer")}><option value="admin">Admin</option><option value="developer">Developer</option></select></div><button type="button" className="desk-save" disabled={busy || !roleId} onClick={async () => { const ok = await send("/api/control/manage", { kind: "role", data: { action: "grant", userId: roleId, role: roleName } }, "Role granted."); if (ok) setRoleId(""); }}>Grant role <Check size={15} /></button></section><section className="desk-panel desk-form-panel"><div className="desk-panel-head"><div><span className="desk-kicker">OPTIONAL SUPABASE AUTH INVITE</span><h2>Invite an Admin</h2></div></div><p className="desk-info">Requires SUPABASE_SECRET_KEY stored only in deployment secrets, and a correctly configured Supabase email invitation flow. No password is generated by this website.</p><div className="desk-field"><label htmlFor="invite-email">Admin email address</label><input id="invite-email" type="email" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} placeholder="admin@example.com" /></div><button type="button" className="desk-save" disabled={busy || !inviteEmail} onClick={async () => { const ok = await send("/api/control/manage", { kind: "role", data: { action: "invite", email: inviteEmail } }, "Invite requested."); if (ok) setInviteEmail(""); }}>Send Supabase invitation <ArrowUpRight size={15} /></button></section></div>}

        {tab === "diagnostics" && developer && <div className="desk-stack"><div className="desk-stats desk-diagnostic-stats"><div><span>DATABASE</span><strong className="desk-status-value">Connected</strong><small>Private SQL connection</small></div><div><span>MIGRATION</span><strong className="desk-status-value">{data.migrationVersion}</strong><small>Latest applied version</small></div><div><span>FAILED ALERTS</span><strong>{data.counts.failedNotifications}</strong><small>Review in Operations</small></div></div><section className="desk-panel"><div className="desk-panel-head"><div><span className="desk-kicker">SAFE STATUS ONLY</span><h2>Integration configuration</h2></div></div><div className="desk-diagnostic-list">{Object.entries(data.diagnostics).map(([name, status]) => <div key={name}><span>{name}</span><strong className={status.startsWith("Not") ? "diag-off" : "diag-on"}>{status}</strong></div>)}</div><p className="desk-info">“Configured” does not prove provider billing, sender verification, chat access or successful delivery. Use credential checks and an approved end-to-end test.</p></section><section className="desk-panel"><div className="desk-panel-head"><div><span className="desk-kicker">ACCOUNTABILITY</span><h2>Recent audit actions</h2></div></div>{data.audits.length ? data.audits.map((row) => <div className="desk-audit" key={text(row.id)}><span>{text(row.action)}</span><small>{text(row.targetType)} · {friendlyDate(row.createdAt)}</small></div>) : <div className="desk-empty">No control actions recorded yet.</div>}</section><section className="desk-panel"><h2>Backups & recovery</h2><p className="desk-info">Database backups must be enabled, monitored and restoration-tested in your Supabase plan. This website does not configure backups automatically. Export content before major changes and keep migration files versioned.</p></section></div>}
      </main>
    </div>

    {editing && <div className="desk-modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setEditing(null); }}><section className="desk-modal" role="dialog" aria-modal="true" aria-label={`Edit ${collectionLabels[editing.entity]}`}><div className="desk-modal-head"><div><span className="desk-kicker">CONTENT EDITOR</span><h2>{editing.id ? "Edit" : "Add"} {collectionLabels[editing.entity]}</h2></div><button type="button" onClick={() => setEditing(null)} aria-label="Close editor"><X size={21} /></button></div><form onSubmit={saveRecord}><div className="desk-form-grid">{fields[editing.entity].map((field) => <FieldInput key={field.key} id="record" field={field} value={form[field.key]} onChange={(value) => setForm((v) => ({ ...v, [field.key]: value }))} />)}</div><div className="desk-modal-actions"><button type="button" onClick={() => setEditing(null)}>Cancel</button><button className="desk-save" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={16} /> : <Check size={16} />} Save content</button></div></form></section></div>}
    {selectedEnquiry && <div className="desk-modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) setSelectedEnquiry(null); }}><section className="desk-modal desk-enquiry-modal" role="dialog" aria-modal="true" aria-label="Private enquiry details"><div className="desk-modal-head"><div><span className="desk-kicker">PRIVATE CUSTOMER ENQUIRY</span><h2>{text(selectedEnquiry.fullName)}</h2></div><button type="button" onClick={() => setSelectedEnquiry(null)} aria-label="Close enquiry"><X size={21} /></button></div><div className="desk-enquiry-meta"><div><span>RECEIVED</span><strong>{friendlyDate(selectedEnquiry.createdAt)}</strong></div><div><span>SERVICE</span><strong>{text(selectedEnquiry.service)}</strong></div><div><span>DESTINATION</span><strong>{text(selectedEnquiry.destination) || "Not chosen"}</strong></div><div><span>CONSENT</span><strong>{friendlyDate(selectedEnquiry.consentAt)}</strong></div></div><div className="desk-enquiry-contacts"><a href={`mailto:${text(selectedEnquiry.email)}`}>{text(selectedEnquiry.email)}</a><a href={`tel:${text(selectedEnquiry.phone).replace(/[^+\d]/g, "")}`}>{text(selectedEnquiry.phone)}</a></div><div className="desk-enquiry-message"><span>THEIR MESSAGE</span><p>{text(selectedEnquiry.message)}</p></div><div className="desk-field"><label htmlFor="enquiry-status">Internal status</label><select id="enquiry-status" value={enquiryStatus} onChange={(e) => setEnquiryStatus(e.target.value)}><option value="new">New</option><option value="contacted">Contacted</option><option value="resolved">Resolved</option></select></div><div className="desk-field"><label htmlFor="enquiry-notes">Private notes (never public)</label><textarea id="enquiry-notes" rows={4} maxLength={3000} value={notes} onChange={(e) => setNotes(e.target.value)} /></div><div className="desk-modal-actions"><button type="button" className="desk-delete" onClick={() => updateEnquiry("delete")}><Trash2 size={15} /> Delete for privacy</button><button type="button" className="desk-save" disabled={busy} onClick={() => updateEnquiry("update")}>Save enquiry <Check size={16} /></button></div></section></div>}
  </div>;
}
