"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ArrowDown, ArrowRight, ArrowUpRight, ChevronLeft, ChevronRight, Compass, LockKeyhole, MapPin, Phone, Plus } from "lucide-react";
import { images, imageLibrary, videos, type ImageAsset } from "@/lib/assets";
import type { PublicContent, PublicDestination, PublicService } from "@/lib/content";
import { CinematicVideo, SafeImage, BrandLogo } from "@/components/media";
import { IntroOverlay, SiteFooter, SiteHeader, telHref } from "@/components/site-chrome";
import { EnquiryForm } from "@/components/enquiry-form";
import { AssistantWidget } from "@/components/assistant";

const routePoints: Record<string, [number, number]> = {
  canada: [25, 30], "united-states": [29, 48], "united-kingdom": [48, 29],
  "united-arab-emirates": [63, 53], oman: [67, 62], turkey: [56, 45], georgia: [61, 35], albania: [52, 51],
};
function Asset({ id, className = "", alt }: { id: string; className?: string; alt?: string }) {
  return <SafeImage asset={images[id] || images.explore} className={className} alt={alt} />;
}
function FormLink({ children, service, destination, className = "text-link" }: {
  children: React.ReactNode; service?: string; destination?: string; className?: string;
}) {
  return <a href="#contact" className={className} onClick={() => {
    if (service) window.dispatchEvent(new CustomEvent("aa:service", { detail: service }));
    if (destination) window.dispatchEvent(new CustomEvent("aa:destination", { detail: destination }));
  }}>{children}</a>;
}
function Eyebrow({ children, light = false }: { children: React.ReactNode; light?: boolean }) {
  return <span className={`eyebrow ${light ? "eyebrow-light" : "eyebrow-blue"}`}><span className="eyebrow-line" />{children}</span>;
}

function Hero({ content }: { content: PublicContent }) {
  const { settings } = content;
  const suggested = settings.heroHeadline === "Your Next Chapter Starts Beyond Borders.";
  return <section className="hero" id="home" aria-labelledby="hero-title">
    <CinematicVideo asset={videos.hero} className="hero-video" hero />
    <div className="hero-tint" aria-hidden="true" />
    <div className="container-wide hero-inner">
      <div className="hero-copy">
        <Eyebrow light>GLOBAL POSSIBILITIES, PERSONALLY GUIDED</Eyebrow>
        <h1 id="hero-title">{suggested ? <>Your Next Chapter<br />Starts <em>Beyond</em><br /><em>Borders.</em></> : settings.heroHeadline}</h1>
        <p>{settings.heroSubheadline}</p>
        <div className="hero-actions"><FormLink className="button button-blue" >Start Your Journey <ArrowUpRight size={19} /></FormLink><a href="#services" className="button button-outline">Explore Our Services <ArrowRight size={18} /></a></div>
      </div>
      <div className="hero-side-note" aria-hidden="true"><span>THE WORLD IS WAITING</span><span className="side-rule" /><span>01 — A&A GLOBALCARE</span></div>
    </div>
    <div className="hero-foot container-wide"><span>FROM YOUR FIRST QUESTION TO YOUR NEXT STEP</span><a href="#intro" aria-label="Scroll to discover more"><span>SCROLL TO EXPLORE</span><ArrowDown size={17} /></a></div>
  </section>;
}

function TrustStrip() {
  return <div className="trust-strip" aria-label="Areas of support"><div className="container-wide trust-inner">
    {["Travel support", "Visa guidance", "Study abroad guidance", "Career consultation"].map((item, i) => <div className="trust-item" key={item}><span className="trust-number">0{i + 1}</span><span>{item}</span><ArrowUpRight size={16} aria-hidden="true" /></div>)}
  </div></div>;
}

function Introduction({ content }: { content: PublicContent }) {
  return <section className="intro-section section-pad" id="intro"><div className="container-wide intro-grid">
    <div className="intro-text reveal"><Eyebrow>THE WAY FORWARD</Eyebrow><h2>Every journey starts with <em>a conversation.</em></h2><p className="large-copy">We believe the best next step begins with understanding where you want to go.</p><p>{content.settings.introduction}</p><a href="#about" className="text-link dark-link">Get to know our approach <ArrowUpRight size={17} /></a></div>
    <div className="intro-composition reveal"><div className="intro-image-main"><Asset id="consultant" alt="Travel consultation image supplied for A&A Globalcare" /></div><div className="intro-image-small"><Asset id="globe" alt="Globe representing international opportunities" /></div><div className="intro-image-caption"><span className="caption-cross">✳</span><span>Thoughtful support<br />for the journey ahead.</span></div></div>
  </div></section>;
}

function DestinationsSection({ destinations }: { destinations: PublicDestination[] }) {
  const [slug, setSlug] = useState(destinations[0]?.slug || "");
  const selected = destinations.find((d) => d.slug === slug) || destinations[0];
  if (!selected) return null;
  return <section className="destinations-section section-pad" id="destinations">
    <div className="container-wide"><div className="section-heading destinations-heading reveal"><div><Eyebrow light>THE PLACES IN VIEW</Eyebrow><h2>A wider world.<br /><em>Your way forward.</em></h2></div><p>Explore the destinations shown on our supplied material. Availability and requirements vary—ask our team what&apos;s current for your plans.</p></div>
      <div className="destination-layout reveal"><div className="destination-map" aria-label="Select a destination from the markers or list">
        <CinematicVideo asset={videos.globe} className="globe-video" /><Asset id="worldMap" className="map-ghost" alt="" />
        <svg className="route-svg" viewBox="0 0 800 560" preserveAspectRatio="none" aria-hidden="true"><path d="M105 410 C 190 260 280 200 395 255 S 615 430 730 165" /><path d="M180 170 C 305 360 410 380 670 230" /><circle cx="400" cy="280" r="235" /></svg>
        <div className="map-grid" aria-hidden="true" />
        {destinations.map((d, i) => { const point = routePoints[d.slug] || [28 + (i % 4) * 15, 29 + Math.floor(i / 4) * 27]; return <button type="button" key={d.id} className={`destination-pin ${selected.slug === d.slug ? "pin-active" : ""}`} style={{ left: `${point[0]}%`, top: `${point[1]}%` }} aria-label={`Explore ${d.country}`} aria-pressed={selected.slug === d.slug} onClick={() => setSlug(d.slug)}><span className="pin-core" /><span className="pin-label">{d.country}</span></button>; })}
        <div className="map-corner-label"><Compass size={16} /><span>EXPLORE THE POSSIBILITIES</span></div>
      </div><div className="destination-detail" key={selected.slug}><div className="destination-detail-photo"><SafeImage asset={images[selected.imageKey] || images.explore} alt={images[selected.imageKey]?.alt || selected.country} /><span>DESTINATION / {String(destinations.findIndex((d) => d.slug === selected.slug) + 1).padStart(2, "0")}</span></div><div className="destination-detail-body"><span className="detail-kicker">ON THE MAP</span><h3>{selected.country}</h3><p>{selected.summary}</p><small>{selected.serviceNotes}</small><FormLink destination={selected.slug} className="text-link light-link">Enquire about {selected.country} <ArrowUpRight size={17} /></FormLink></div></div></div>
      <div className="destination-tabs" aria-label="Destinations">{destinations.map((d) => <button key={d.id} type="button" className={selected.slug === d.slug ? "active" : ""} aria-pressed={selected.slug === d.slug} onClick={() => setSlug(d.slug)}>{d.country}<ArrowUpRight size={14} /></button>)}</div>
      <div className="destination-cities"><CinematicVideo asset={videos.cities} /><div><span>NEW PLACES. NEW PERSPECTIVES.</span><p>Explore with clarity, not assumptions.</p></div></div>
    </div>
  </section>;
}

function ServicesSection({ services }: { services: PublicService[] }) {
  return <section className="services-section section-pad" id="services"><div className="container-wide"><div className="section-heading services-heading reveal"><div><Eyebrow>WHAT WE CAN HELP YOU EXPLORE</Eyebrow><h2>Support for the<br /><em>journey you choose.</em></h2></div><p>Different ambitions. Different routes. One thoughtful place to begin the conversation.</p></div>
    <div className="service-list">{services.map((s, i) => <article className={`service-row reveal ${i % 2 ? "service-row-reverse" : ""}`} key={s.id}><div className="service-visual"><SafeImage asset={images[s.imageKey] || images.explore} alt={images[s.imageKey]?.alt || s.title} /><div className="service-video-inset"><CinematicVideo asset={videos[s.videoKey] || videos.airport} /></div><span className="service-visual-count">0{i + 1} / 0{services.length}</span></div><div className="service-copy"><span className="service-index">0{i + 1} <span>—</span> {s.title.toUpperCase()}</span><h3>{s.summary}</h3><p>{s.body}</p><div className="service-includes"><span>HOW WE MAY HELP</span>{s.includes.map((item) => <div key={item}><span className="tiny-dash" />{item}</div>)}</div><FormLink service={s.slug} className="text-link dark-link">Discuss this service <ArrowUpRight size={18} /></FormLink></div></article>)}</div>
  </div></section>;
}

const visaSteps = [
  ["Initial consultation", "Tell us about your plans and the type of application you are considering."],
  ["Understand requirements", "Look at your destination and the current requirements to check with official sources."],
  ["Prepare documents", "Work through a relevant checklist and organise what may be needed."],
  ["Application guidance", "Receive support as you navigate the application process."],
  ["Follow-up & next steps", "Talk through what happens next, whatever the decision may be."],
];
function VisaJourney() {
  return <section className="visa-section section-pad" id="visa"><div className="container-wide"><div className="visa-heading reveal"><Eyebrow light>VISA APPLICATION GUIDANCE</Eyebrow><h2>Clarity in the details.<br /><em>Confidence in the process.</em></h2><p>Applications can feel complex. A careful, step-by-step approach makes it easier to know what to ask and prepare.</p></div><div className="visa-grid"><div className="visa-media reveal"><div className="visa-video"><CinematicVideo asset={videos.visa} /></div><div className="visa-photo visa-photo-one"><Asset id="visaConsultation" /></div><div className="visa-photo visa-photo-two"><Asset id="documents" /></div><div className="visa-media-caption"><span>01 — 05</span><span>PREPARE WITH PURPOSE</span></div></div><div className="visa-steps reveal">{visaSteps.map(([title, text], i) => <div className="visa-step" key={title}><span className="step-num">0{i + 1}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowUpRight size={17} aria-hidden="true" /></div>)}<div className="visa-caveat"><LockKeyhole size={18} /><p>Final decisions belong to relevant authorities. Requirements vary by destination and application type. No approval is guaranteed.</p></div></div></div><div className="visa-bottom-images"><Asset id="passport" /><Asset id="visaJourney" /></div></div></section>;
}

function StudySection() {
  return <section className="study-section section-pad" id="study"><div className="container-wide study-grid"><div className="study-gallery reveal"><div className="study-gallery-main"><Asset id="campus" /></div><div className="study-gallery-student"><Asset id="student" /></div><div className="study-gallery-graduation"><Asset id="graduation" /></div><div className="study-gallery-label">A FUTURE TO EXPLORE <ArrowUpRight size={18} /></div></div><div className="study-copy reveal"><Eyebrow>STUDY ABROAD</Eyebrow><h2>Where curiosity<br />can take you <em>further.</em></h2><p className="large-copy">A new place to learn can open up a whole new perspective.</p><p>Explore study destinations, understand entry requirements, prepare relevant documents and plan the next steps that make sense for you. We&apos;re here to help you think through the process—not to promise an admission outcome.</p><div className="study-points"><span>Explore your options</span><span>Understand requirements</span><span>Plan your next steps</span></div><FormLink service="study-abroad" className="text-link dark-link">Talk about studying abroad <ArrowUpRight size={18} /></FormLink></div></div><div className="container-wide study-band reveal"><div className="study-band-video"><CinematicVideo asset={videos.study} /></div><div className="study-band-photo"><Asset id="studying" /></div><div className="study-band-caption"><span>THE NEXT CHAPTER</span><p>Start with the right questions.</p></div></div></section>;
}

function CareerSection() {
  return <section className="career-section section-pad" id="career"><div className="container-wide career-grid"><div className="career-copy reveal"><Eyebrow>INTERNATIONAL CAREER</Eyebrow><h2>Your ambition<br />deserves <em>direction.</em></h2><p className="large-copy">Global career plans begin with understanding your own goals.</p><p>We can discuss pathways, preparation and considerations that may be relevant to an international career. Programme availability, eligibility and outcomes vary. Jobs, work permits and salaries cannot be promised.</p><FormLink service="employment-programs" className="text-link dark-link">Discuss your career goals <ArrowUpRight size={18} /></FormLink><div className="career-mini"><div><Asset id="interview" /></div><span>PREPARATION IS PART OF THE JOURNEY</span></div></div><div className="career-visual reveal"><div className="career-photo"><Asset id="professional" /></div><div className="career-motion"><CinematicVideo asset={videos.career} /></div><div className="career-accent-photo"><Asset id="careerSuccess" /></div></div></div></section>;
}

const experienceFrames: Array<{ number: string; title: string; note: string; image: string; video?: keyof typeof videos }> = [
  { number: "01", title: "The first step", note: "Every departure begins somewhere.", image: "journeyBegins", video: "suitcase" },
  { number: "02", title: "A change of view", note: "The world looks different in motion.", image: "window", video: "airplaneClouds" },
  { number: "03", title: "In between places", note: "Plans made real, one moment at a time.", image: "departure" },
  { number: "04", title: "A new horizon", note: "The next chapter comes into view.", image: "airplaneClose", video: "takeoff" },
  { number: "05", title: "The arrival", note: "A place to begin again.", image: "arrival" },
];
function ExperienceSection() {
  const rail = useRef<HTMLDivElement>(null);
  return <section className="experience-section section-pad" id="experience"><div className="container-wide experience-heading reveal"><div><Eyebrow light>THE EXPERIENCE OF GOING FURTHER</Eyebrow><h2>More than a destination.<br /><em>A story in motion.</em></h2></div><div className="rail-controls"><button type="button" onClick={() => rail.current?.scrollBy({ left: -370, behavior: "smooth" })} aria-label="Scroll stories left"><ChevronLeft size={22} /></button><button type="button" onClick={() => rail.current?.scrollBy({ left: 370, behavior: "smooth" })} aria-label="Scroll stories right"><ChevronRight size={22} /></button></div></div><div className="experience-rail" ref={rail} aria-label="Travel moments, scroll horizontally">{experienceFrames.map((frame) => <article className="experience-card" key={frame.number}><div className="experience-card-media"><Asset id={frame.image} />{frame.video && <CinematicVideo asset={videos[frame.video]} />}<span>{frame.number} / 05</span></div><div className="experience-card-text"><h3>{frame.title}</h3><p>{frame.note}</p></div></article>)}</div><div className="container-wide experience-foot"><span>SWIPE TO EXPLORE ON TOUCH SCREENS</span><span className="experience-line" /></div></section>;
}

const processSteps = [
  ["Tell us your goal", "Share where you hope to go and what you are planning."],
  ["Have a conversation", "We listen first and talk through your questions."],
  ["Review next steps", "Explore options and relevant requirements together."],
  ["Prepare thoughtfully", "Organise the documents and information you may need."],
  ["Stay in contact", "Keep the conversation going as your plans progress."],
];
function ProcessSection() {
  return <section className="process-section section-pad" id="process"><div className="container-wide"><div className="process-heading reveal"><Eyebrow>HOW IT WORKS</Eyebrow><h2>A clear path starts<br />with <em>one small step.</em></h2><p>No complicated promises. Just a more thoughtful way to move forward.</p></div><div className="process-grid">{processSteps.map(([title, text], i) => <div className="process-step reveal" key={title}><span className="process-dot"><span /></span><span className="process-number">0{i + 1}</span><h3>{title}</h3><p>{text}</p></div>)}</div><FormLink className="button button-dark">Take the first step <ArrowUpRight size={18} /></FormLink></div></section>;
}

function AboutSection({ content }: { content: PublicContent }) {
  return <section className="about-section section-pad" id="about"><CinematicVideo asset={videos.clouds} className="about-atmosphere" /><div className="about-tint" /><div className="container-wide about-grid"><div className="about-copy reveal"><Eyebrow light>ABOUT A&A GLOBALCARE</Eyebrow><h2>People first.<br /><em>Possibilities always.</em></h2><p>{content.settings.introduction}</p><div className="about-principles"><span>TRUSTED & RELIABLE</span><span>PROFESSIONAL SERVICE</span><span>GLOBAL NETWORK</span>{content.settings.support24hConfirmed && <span>24/7 SUPPORT</span>}</div><small>These phrases are from the company&apos;s original material. Specific availability and claims should be confirmed with the company.</small></div><div className="about-images reveal"><div className="about-photo-large"><Asset id="team" /></div><div className="about-photo-small"><Asset id="clientConsultation" /></div><div className="about-photo-office"><Asset id="office" /></div><span className="about-image-mark">A&A / THE HUMAN SIDE OF GOING GLOBAL</span></div></div></section>;
}

function JournalSection({ content }: { content: PublicContent }) {
  const [expanded, setExpanded] = useState(false);
  const highlights = [images.couple, images.family, images.businessTraveler, images.airport, images.explore, images.future];
  const journalItems: ImageAsset[] = content.gallery.map((g) => ({ id: g.id, title: g.title, url: g.assetUrl, alt: g.alt, fallback: "/images/travel-fallback.jpg", category: "travel" }));
  const shown = expanded ? [...imageLibrary, ...journalItems] : [...highlights, ...journalItems.slice(0, 2)];
  return <section className="journal-section section-pad" id="journal"><div className="container-wide"><div className="journal-head reveal"><div><Eyebrow>AN EDITORIAL VIEW</Eyebrow><h2>Moments that move <em>us.</em></h2></div><p>Scenes of travel, learning and possibility from the supplied image collection.</p></div><div className={`journal-grid ${expanded ? "journal-expanded" : ""}`}>{shown.map((item, i) => <figure className="journal-item" key={`${item.id}-${i}`}><SafeImage asset={item} /><figcaption><span>{String(i + 1).padStart(2, "0")} / VISUAL STORY</span><strong>{item.title}</strong></figcaption></figure>)}</div><button className="text-link dark-link journal-more" type="button" aria-expanded={expanded} onClick={() => setExpanded(!expanded)}>{expanded ? "Show fewer images" : "Explore the visual library"} <ArrowUpRight size={18} /></button></div></section>;
}

function FaqSection({ content }: { content: PublicContent }) {
  return <section className="faq-section section-pad" id="faqs"><div className="container-wide faq-grid"><div className="faq-intro reveal"><Eyebrow>GOOD QUESTIONS, THOUGHTFUL ANSWERS</Eyebrow><h2>Before you go,<br /><em>let&apos;s make it clear.</em></h2><p>Every journey is different. Here are a few good places to start.</p><FormLink className="text-link dark-link">Still have a question? Ask us <ArrowUpRight size={17} /></FormLink></div><div className="faq-list reveal">{content.faqs.map((item, i) => <details key={item.id} className="faq-item"><summary><span className="faq-num">0{i + 1}</span><span>{item.question}</span><Plus size={19} className="faq-plus" aria-hidden="true" /></summary><p>{item.answer}</p></details>)}</div></div></section>;
}

function Testimonials({ content }: { content: PublicContent }) {
  if (!content.testimonials.length) return null;
  return <section className="testimonials-section section-pad"><div className="container-wide"><Eyebrow>SHARED WITH PERMISSION</Eyebrow><h2>Stories from the journey.</h2><div className="testimonials-grid">{content.testimonials.map((t) => <figure key={t.id}><blockquote>“{t.quote}”</blockquote><figcaption>{t.displayName}{t.roleLocation && <span> · {t.roleLocation}</span>}</figcaption></figure>)}</div></div></section>;
}

function FinalCall() {
  return <section className="final-call"><CinematicVideo asset={videos.final} className="final-video" /><div className="final-tint" /><div className="container-wide final-inner reveal"><Eyebrow light>THIS IS YOUR INVITATION</Eyebrow><h2>Where could your<br /><em>next chapter begin?</em></h2><p>Tell us what you are planning. We&apos;ll help you talk through the next steps.</p><FormLink className="button button-white">Start your journey <ArrowUpRight size={18} /></FormLink></div><div className="final-watermark" aria-hidden="true">A&A</div></section>;
}

function ContactSection({ content }: { content: PublicContent }) {
  const { settings } = content;
  return <section className="contact-section section-pad" id="contact"><div className="container-wide contact-grid"><div className="contact-info reveal"><Eyebrow>GET IN TOUCH</Eyebrow><h2>The conversation<br />starts <em>here.</em></h2><p>Tell us what you have in mind. We&apos;ll help you explore your next step with clarity.</p><div className="contact-rule" /><span className="contact-label">CALL US DIRECTLY</span><a href={telHref(settings.phonePrimary)} className="contact-phone"><Phone size={21} />{settings.phonePrimary}<ArrowUpRight size={17} /></a><a href={telHref(settings.phoneSecondary)} className="contact-phone"><Phone size={21} />{settings.phoneSecondary}<ArrowUpRight size={17} /></a>{settings.publicEmail && <a className="contact-email" href={`mailto:${settings.publicEmail}`}>{settings.publicEmail}</a>}{settings.whatsapp && <a className="text-link light-link" href={`https://wa.me/${settings.whatsapp.replace(/\D/g, "")}?text=${encodeURIComponent("Hello A&A Globalcare, I would like to discuss my plans.")}`} target="_blank" rel="noopener noreferrer">Message on WhatsApp <ArrowUpRight size={17} /></a>}<div className="contact-address"><MapPin size={21} /><div><strong>OUR ADDRESS</strong><p>{settings.address}</p>{!settings.addressConfirmed && <small>Please call to confirm directions before visiting.</small>}{settings.addressConfirmed && settings.mapUrl && <a href={settings.mapUrl} target="_blank" rel="noopener noreferrer">Open map <ArrowUpRight size={14} /></a>}</div></div></div><div className="contact-form-panel reveal"><EnquiryForm services={content.services} destinations={content.destinations} /></div></div></section>;
}

export function Maintenance({ content }: { content: PublicContent }) {
  return <main className="maintenance-screen"><div className="maintenance-orbit" /><div className="maintenance-content"><BrandLogo light /><Eyebrow light>A&A GLOBALCARE</Eyebrow><h1>{content.settings.siteStatus === "suspended" ? "We'll be back soon." : "A short pause in the journey."}</h1><p>{content.settings.statusMessage}</p><div className="maintenance-phones"><a href={telHref(content.settings.phonePrimary)}>{content.settings.phonePrimary} <ArrowUpRight size={17} /></a><a href={telHref(content.settings.phoneSecondary)}>{content.settings.phoneSecondary} <ArrowUpRight size={17} /></a></div></div><span className="maintenance-foot">© {new Date().getFullYear()} {content.settings.brandName}</span></main>;
}

export function PublicSite({ content }: { content: PublicContent }) {
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const elements = document.querySelectorAll<HTMLElement>(".reveal");
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add("is-visible"); observer.unobserve(entry.target); }
    }), { rootMargin: "0px 0px -35px 0px", threshold: 0.08 });
    elements.forEach((element) => { element.classList.add("will-reveal"); observer.observe(element); });
    return () => observer.disconnect();
  }, []);
  if (content.settings.siteStatus !== "live") return <Maintenance content={content} />;
  const sections: Record<string, React.ReactNode> = {
    destinations: <DestinationsSection destinations={content.destinations} />,
    services: <ServicesSection services={content.services} />,
    visa: <VisaJourney />,
    study: <StudySection />,
    career: <CareerSection />,
    experience: <ExperienceSection />,
    process: <ProcessSection />,
    about: <AboutSection content={content} />,
    journal: <JournalSection content={content} />,
    faqs: <FaqSection content={content} />,
    contact: <ContactSection content={content} />,
  };
  const ordered = [...new Set([...content.settings.sectionOrder.filter((id) => id in sections), ...Object.keys(sections)])];
  return <><IntroOverlay /><SiteHeader settings={content.settings} /><main><Hero content={content} />{content.announcements.length > 0 && <div className="announcement-bar" role="status"><div className="container-wide"><span>NOTICE</span>{content.announcements.map((a) => <p key={a.id}><strong>{a.title}</strong> — {a.body}</p>)}</div></div>}<TrustStrip /><Introduction content={content} />{ordered.map((id) => <div key={id}>{sections[id]}</div>)}<Testimonials content={content} /><FinalCall /></main><SiteFooter settings={content.settings} /><AssistantWidget settings={content.settings} /></>;
}
