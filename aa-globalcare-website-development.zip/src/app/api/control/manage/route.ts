import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { db } from "@/db";
import { aiConversations, aiSettings, enquiries, integrationSettings, siteSettings, userRoles } from "@/db/schema";
import { count, eq, lt, sql } from "drizzle-orm";
import { getControlUser } from "@/lib/auth";
import { sectionIds } from "@/lib/content";
import { deliverNotifications } from "@/lib/notifications";
import { acceptsJson, noStoreJson, rateLimit, sameOrigin, shortPlainText, writeAudit } from "@/lib/security";
import { getSecret, removeSecret, saveSecret, secretNames, secretStoreReady, type SecretName } from "@/lib/secrets";

export const dynamic = "force-dynamic";
const envelope = z.object({ kind: z.enum(["site", "ai", "integrations", "secret", "role", "enquiry", "conversation", "test", "retry"]), data: z.unknown() });
const siteInput = z.object({ siteStatus: z.enum(["live", "maintenance", "suspended"]), statusMessage: z.string().trim().min(10).max(500),
  sectionOrder: z.array(z.string()).min(1).max(20).refine((values) => new Set(values).size === values.length && values.every((v) => sectionIds.includes(v))) });
const aiInput = z.object({ provider: z.enum(["disabled", "xai", "groq"]), model: z.string().trim().max(80).regex(/^[a-zA-Z0-9._/-]*$/),
  enabled: z.boolean(), additionalGuidance: z.string().max(1000), retentionDays: z.coerce.number().int().min(1).max(365) });
const integrationInput = z.object({ brevoEnabled: z.boolean(), brevoSenderName: z.string().trim().max(120), brevoSenderEmail: z.union([z.email(), z.literal("")]),
  notificationEmail: z.union([z.email(), z.literal("")]), telegramEnabled: z.boolean(), whatsappVerified: z.boolean() });
const secretInput = z.object({ name: z.enum(secretNames), action: z.enum(["set", "remove"]), value: z.string().optional() });
const roleInput = z.object({ action: z.enum(["grant", "revoke", "invite"]), userId: z.uuid().optional(), role: z.enum(["admin", "developer"]).optional(), email: z.email().optional() });
const enquiryInput = z.object({ action: z.enum(["update", "delete"]), id: z.uuid(), status: z.enum(["new", "contacted", "resolved"]).optional(), privateNotes: z.string().max(3000).optional() });
const conversationInput = z.object({ action: z.enum(["delete", "purge"]), id: z.uuid().optional() });
const testInput = z.object({ channel: z.enum(["brevo", "telegram"]) });
const retryInput = z.object({ id: z.uuid() });

export async function POST(request: Request) {
  if (!sameOrigin(request) || !acceptsJson(request)) return noStoreJson({ message: "Invalid request." }, 400);
  const user = await getControlUser();
  if (!user) return noStoreJson({ message: "Unauthorized" }, 401);
  try {
    if (!(await rateLimit("control-actions", request, 120, 3600))) return noStoreJson({ message: "Please wait before making more changes." }, 429);
    const parsed = envelope.safeParse(await request.json());
    if (!parsed.success) return noStoreJson({ message: "Invalid action." }, 400);
    const { kind, data } = parsed.data;
    if (["site", "ai", "integrations", "secret", "role"].includes(kind) && user.role !== "developer") return noStoreJson({ message: "Developer permission required." }, 403);
    if (kind === "site") {
      const value = siteInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Please check site status and section order." }, 400);
      await db.update(siteSettings).set(value.data).where(eq(siteSettings.id, 1));
      await writeAudit(user.id, "developer.site_status", "site_settings", "1", { status: value.data.siteStatus });
    } else if (kind === "ai") {
      const value = aiInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Please check the AI settings." }, 400);
      await db.update(aiSettings).set(value.data).where(eq(aiSettings.id, 1));
      await writeAudit(user.id, "developer.ai_settings", "ai_settings", "1", { provider: value.data.provider, enabled: value.data.enabled });
    } else if (kind === "integrations") {
      const value = integrationInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Please check the integration settings." }, 400);
      const v = value.data;
      await db.update(integrationSettings).set({ ...v, brevoSenderName: v.brevoSenderName || null,
        brevoSenderEmail: v.brevoSenderEmail || null, notificationEmail: v.notificationEmail || null }).where(eq(integrationSettings.id, 1));
      await writeAudit(user.id, "developer.integrations", "integration_settings", "1", { brevoEnabled: v.brevoEnabled, telegramEnabled: v.telegramEnabled, whatsappVerified: v.whatsappVerified });
    } else if (kind === "secret") {
      const value = secretInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Invalid secret configuration." }, 400);
      if (!secretStoreReady()) return noStoreJson({ message: "Encrypted secret storage is not configured. Set CONTROL_ENCRYPTION_KEY as a deployment secret." }, 503);
      if (value.data.action === "set") {
        if (!value.data.value || value.data.value.length < 10 || value.data.value.length > 500) return noStoreJson({ message: "Enter a valid secret value." }, 400);
        await saveSecret(value.data.name as SecretName, value.data.value);
      } else await removeSecret(value.data.name as SecretName);
      await writeAudit(user.id, `developer.secret_${value.data.action}`, "encrypted_secrets", value.data.name);
    } else if (kind === "role") {
      const value = roleInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Invalid role request." }, 400);
      const v = value.data;
      if (v.action === "invite") {
        if (!v.email || !process.env.SUPABASE_SECRET_KEY || !process.env.SUPABASE_URL) return noStoreJson({ message: "Invitations require a private Supabase secret key and a valid email." }, 503);
        const admin = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SECRET_KEY, { auth: { autoRefreshToken: false, persistSession: false } });
        const { data: invited, error } = await admin.auth.admin.inviteUserByEmail(v.email);
        if (error || !invited.user) return noStoreJson({ message: "Unable to send the invitation. Check Supabase Auth configuration." }, 400);
        await db.insert(userRoles).values({ userId: invited.user.id, role: "admin" }).onConflictDoUpdate({ target: userRoles.userId, set: { role: "admin" } });
        await writeAudit(user.id, "developer.role_invite", "user_roles", invited.user.id, { role: "admin" });
        return noStoreJson({ ok: true, message: "Admin invitation requested through Supabase Auth." });
      }
      if (!v.userId) return noStoreJson({ message: "A Supabase user ID is required." }, 400);
      if (v.action === "revoke") {
        const [target] = await db.select().from(userRoles).where(eq(userRoles.userId, v.userId)).limit(1);
        if (target?.role === "developer") {
          const [developers] = await db.select({ value: count() }).from(userRoles).where(eq(userRoles.role, "developer"));
          if (Number(developers?.value || 0) <= 1) return noStoreJson({ message: "The last Developer role cannot be removed." }, 400);
        }
        await db.delete(userRoles).where(eq(userRoles.userId, v.userId));
      } else {
        if (!v.role) return noStoreJson({ message: "Choose Admin or Developer." }, 400);
        const [existing] = await db.select({ role: userRoles.role }).from(userRoles).where(eq(userRoles.userId, v.userId)).limit(1);
        if (existing?.role === "developer" && v.role !== "developer") {
          const [developers] = await db.select({ value: count() }).from(userRoles).where(eq(userRoles.role, "developer"));
          if (Number(developers?.value || 0) <= 1) return noStoreJson({ message: "The last Developer role cannot be changed." }, 400);
        }
        await db.insert(userRoles).values({ userId: v.userId, role: v.role }).onConflictDoUpdate({ target: userRoles.userId, set: { role: v.role } });
      }
      await writeAudit(user.id, `developer.role_${v.action}`, "user_roles", v.userId, { role: v.role || "revoked" });
    } else if (kind === "enquiry") {
      const value = enquiryInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Invalid enquiry action." }, 400);
      if (value.data.action === "delete") await db.delete(enquiries).where(eq(enquiries.id, value.data.id));
      else await db.update(enquiries).set({ status: value.data.status || "new", privateNotes: shortPlainText(value.data.privateNotes || "", 3000) }).where(eq(enquiries.id, value.data.id));
      await writeAudit(user.id, `enquiry.${value.data.action}`, "enquiries", value.data.id, value.data.status ? { status: value.data.status } : {});
    } else if (kind === "conversation") {
      const value = conversationInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Invalid conversation action." }, 400);
      if (value.data.action === "delete") {
        if (!value.data.id) return noStoreJson({ message: "Conversation ID required." }, 400);
        await db.delete(aiConversations).where(eq(aiConversations.id, value.data.id));
      } else {
        const [settings] = await db.select().from(aiSettings).where(eq(aiSettings.id, 1)).limit(1);
        await db.delete(aiConversations).where(lt(aiConversations.createdAt, sql`now() - make_interval(days => ${settings?.retentionDays || 30})`));
      }
      await writeAudit(user.id, `conversation.${value.data.action}`, "ai_conversations", value.data.id);
    } else if (kind === "retry") {
      const value = retryInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Invalid reference." }, 400);
      const [[enquiry], [integration]] = await Promise.all([
        db.select().from(enquiries).where(eq(enquiries.id, value.data.id)).limit(1),
        db.select().from(integrationSettings).where(eq(integrationSettings.id, 1)).limit(1),
      ]);
      if (!enquiry || !integration) return noStoreJson({ message: "Enquiry or integration not found." }, 404);
      await deliverNotifications(enquiry, integration, true);
      await writeAudit(user.id, "notification.retry", "enquiries", value.data.id);
    } else if (kind === "test") {
      const value = testInput.safeParse(data); if (!value.success) return noStoreJson({ message: "Invalid provider." }, 400);
      const channel = value.data.channel;
      const key = await getSecret(channel === "brevo" ? "BREVO_API_KEY" : "TELEGRAM_BOT_TOKEN");
      if (!key) return noStoreJson({ message: "Not configured. Add a credential privately first." }, 503);
      const endpoint = channel === "brevo" ? "https://api.brevo.com/v3/account" : `https://api.telegram.org/bot${key}/getMe`;
      const response = await fetch(endpoint, { signal: AbortSignal.timeout(7000), headers: channel === "brevo" ? { "api-key": key, Accept: "application/json" } : undefined });
      if (!response.ok) return noStoreJson({ message: `Provider check failed (HTTP ${response.status}). No message was sent.` }, 502);
      await writeAudit(user.id, "integration.credential_test", channel);
      return noStoreJson({ ok: true, message: "Credential accepted by provider. Sender verification, chat access and actual delivery are not yet confirmed." });
    }
    return noStoreJson({ ok: true });
  } catch { return noStoreJson({ message: "This action could not be completed. Please check the configuration and try again." }, 503); }
}
