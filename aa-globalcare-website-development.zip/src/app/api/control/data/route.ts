import { getControlUser } from "@/lib/auth";
import { loadControlData } from "@/lib/control-data";
import { noStoreJson } from "@/lib/security";
export const dynamic = "force-dynamic";
export async function GET() {
  const user = await getControlUser();
  if (!user) return noStoreJson({ message: "Unauthorized" }, 401);
  try { return noStoreJson(await loadControlData(user.role)); }
  catch { return noStoreJson({ message: "Unable to load control data." }, 503); }
}
