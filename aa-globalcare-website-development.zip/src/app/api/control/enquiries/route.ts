import { db } from "@/db";
import { enquiries } from "@/db/schema";
import { and, count, desc, eq, ilike, or, type SQL } from "drizzle-orm";
import { getControlUser } from "@/lib/auth";
import { noStoreJson } from "@/lib/security";
export const dynamic = "force-dynamic";
export async function GET(request: Request) {
  const user = await getControlUser();
  if (!user) return noStoreJson({ message: "Unauthorized" }, 401);
  const url = new URL(request.url);
  const page = Math.min(10000, Math.max(1, Number.parseInt(url.searchParams.get("page") || "1", 10) || 1));
  const status = url.searchParams.get("status") || "all";
  const search = (url.searchParams.get("search") || "").trim().slice(0, 100);
  const filters: SQL[] = [];
  if (["new", "contacted", "resolved"].includes(status)) filters.push(eq(enquiries.status, status as "new" | "contacted" | "resolved"));
  if (search) {
    const safe = search.replace(/[\\%_]/g, "\\$&");
    const match = or(ilike(enquiries.fullName, `%${safe}%`), ilike(enquiries.email, `%${safe}%`), ilike(enquiries.phone, `%${safe}%`));
    if (match) filters.push(match);
  }
  const where = filters.length ? and(...filters) : undefined;
  try {
    const [items, totals] = await Promise.all([
      db.select().from(enquiries).where(where).orderBy(desc(enquiries.createdAt)).limit(10).offset((page - 1) * 10),
      db.select({ value: count() }).from(enquiries).where(where),
    ]);
    const total = Number(totals[0]?.value || 0);
    return noStoreJson({ items, total, page, pages: Math.max(1, Math.ceil(total / 10)) });
  } catch { return noStoreJson({ message: "Unable to load enquiries." }, 503); }
}
