import { getControlUser, getSupabaseServer } from "@/lib/auth";
import { noStoreJson, sameOrigin, writeAudit } from "@/lib/security";

export const dynamic = "force-dynamic";
export async function POST(request: Request) {
  if (!sameOrigin(request)) return noStoreJson({ message: "Invalid request." }, 400);
  const user = await getControlUser();
  const supabase = await getSupabaseServer();
  if (user) await writeAudit(user.id, "auth.logout", "user_roles", user.id);
  if (supabase) await supabase.auth.signOut();
  return noStoreJson({ ok: true });
}
