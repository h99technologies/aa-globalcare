import { z } from "zod";
import { db } from "@/db";
import { announcements, destinations, faqs, gallery, services, siteSettings, testimonials } from "@/db/schema";
import { eq } from "drizzle-orm";
import { images, videos } from "@/lib/assets";
import { getControlUser } from "@/lib/auth";
import { acceptsJson, noStoreJson, sameOrigin, shortPlainText, writeAudit } from "@/lib/security";

export const dynamic = "force-dynamic";
const idSchema = z.uuid();
const slug = z.string().trim().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(100);
const imageKey = z.string().refine((value) => !!images[value]);
const videoKey = z.string().refine((value) => !!videos[value]);
const title = z.string().trim().min(2).max(160);
const paragraph = z.string().trim().min(5).max(5000);
const order = z.coerce.number().int().min(0).max(10000);
const serviceSchema = z.object({ title, slug, summary: z.string().trim().min(5).max(500), body: paragraph,
  includes: z.array(z.string().trim().min(2).max(150)).max(10), imageKey, videoKey, sortOrder: order,
  active: z.boolean(), seoTitle: z.string().max(160).optional(), seoDescription: z.string().max(300).optional() }).strict();
const destinationSchema = z.object({ country: title, slug, summary: z.string().trim().min(5).max(500),
  serviceNotes: z.string().trim().min(5).max(500), imageKey, videoKey, sortOrder: order, visible: z.boolean() }).strict();
const faqSchema = z.object({ question: title, answer: paragraph, category: z.string().trim().min(2).max(80), sortOrder: order, published: z.boolean() }).strict();
const testimonialSchema = z.object({ quote: paragraph, displayName: title, roleLocation: z.string().trim().max(160).nullable(),
  consented: z.boolean(), status: z.enum(["pending", "approved", "rejected"]), sortOrder: order }).strict().refine((value) => value.status !== "approved" || value.consented);
const gallerySchema = z.object({ title, assetUrl: z.url().refine((value) => value.startsWith("https://")),
  alt: z.string().trim().min(3).max(240), category: z.string().trim().min(2).max(80),
  sortOrder: order, visible: z.boolean() }).strict();
const announcementSchema = z.object({ title, body: paragraph, status: z.enum(["draft", "published"]),
  startsAt: z.string().nullable(), endsAt: z.string().nullable() }).strict();
const settingsSchema = z.object({ brandName: title, heroHeadline: title, heroSubheadline: paragraph,
  introduction: paragraph, address: paragraph, addressConfirmed: z.boolean(),
  phonePrimary: z.string().regex(/^[+\d().\-\s]{7,30}$/), phoneSecondary: z.string().regex(/^[+\d().\-\s]{7,30}$/),
  publicEmail: z.union([z.email(), z.literal("")]), whatsapp: z.string().regex(/^\+?\d{8,15}$|^$/),
  mapUrl: z.union([z.url().refine((value) => value.startsWith("https://")), z.literal("")]),
  support24hConfirmed: z.boolean(), disclaimer: paragraph, privacyBody: paragraph, termsBody: paragraph,
  seoTitle: title, seoDescription: z.string().trim().min(10).max(300) }).strict();
const envelope = z.object({ entity: z.enum(["services", "destinations", "faqs", "testimonials", "gallery", "announcements", "site_settings"]),
  action: z.enum(["save", "delete"]), id: z.string().optional(), data: z.unknown().optional() });

export async function POST(request: Request) {
  if (!sameOrigin(request) || !acceptsJson(request)) return noStoreJson({ message: "Invalid request." }, 400);
  const user = await getControlUser();
  if (!user) return noStoreJson({ message: "Unauthorized" }, 401);
  try {
    const parsed = envelope.safeParse(await request.json());
    if (!parsed.success) return noStoreJson({ message: "Invalid content request." }, 400);
    const { entity, action, id, data } = parsed.data;
    if (action === "delete") {
      if (!id || !idSchema.safeParse(id).success || entity === "site_settings") return noStoreJson({ message: "Invalid deletion request." }, 400);
      switch (entity) {
        case "services": await db.delete(services).where(eq(services.id, id)); break;
        case "destinations": await db.delete(destinations).where(eq(destinations.id, id)); break;
        case "faqs": await db.delete(faqs).where(eq(faqs.id, id)); break;
        case "testimonials": await db.delete(testimonials).where(eq(testimonials.id, id)); break;
        case "gallery": await db.delete(gallery).where(eq(gallery.id, id)); break;
        case "announcements": await db.delete(announcements).where(eq(announcements.id, id)); break;
      }
      await writeAudit(user.id, "content.delete", entity, id);
      return noStoreJson({ ok: true });
    }
    if (id && entity !== "site_settings" && !idSchema.safeParse(id).success) return noStoreJson({ message: "Invalid record ID." }, 400);
    if (entity === "site_settings") {
      const value = settingsSchema.safeParse(data);
      if (!value.success) return noStoreJson({ message: "Please check the site settings fields." }, 400);
      const v = value.data;
      await db.update(siteSettings).set({ ...v, publicEmail: v.publicEmail || null, whatsapp: v.whatsapp || null,
        mapUrl: v.addressConfirmed && v.mapUrl ? v.mapUrl : null }).where(eq(siteSettings.id, 1));
    } else if (entity === "services") {
      const value = serviceSchema.safeParse(data); if (!value.success) return noStoreJson({ message: "Please check all service fields and asset references." }, 400);
      const v = { ...value.data, summary: shortPlainText(value.data.summary, 500), seoTitle: value.data.seoTitle || null, seoDescription: value.data.seoDescription || null };
      if (id) await db.update(services).set(v).where(eq(services.id, id)); else await db.insert(services).values(v);
    } else if (entity === "destinations") {
      const value = destinationSchema.safeParse(data); if (!value.success) return noStoreJson({ message: "Please check all destination fields." }, 400);
      if (id) await db.update(destinations).set(value.data).where(eq(destinations.id, id)); else await db.insert(destinations).values(value.data);
    } else if (entity === "faqs") {
      const value = faqSchema.safeParse(data); if (!value.success) return noStoreJson({ message: "Please check the FAQ fields." }, 400);
      if (id) await db.update(faqs).set(value.data).where(eq(faqs.id, id)); else await db.insert(faqs).values(value.data);
    } else if (entity === "testimonials") {
      const value = testimonialSchema.safeParse(data); if (!value.success) return noStoreJson({ message: "Approval requires consent and complete, approved wording." }, 400);
      if (id) await db.update(testimonials).set(value.data).where(eq(testimonials.id, id)); else await db.insert(testimonials).values(value.data);
    } else if (entity === "gallery") {
      const value = gallerySchema.safeParse(data); if (!value.success) return noStoreJson({ message: "Use a valid HTTPS asset URL and descriptive alt text." }, 400);
      if (id) await db.update(gallery).set(value.data).where(eq(gallery.id, id)); else await db.insert(gallery).values(value.data);
    } else if (entity === "announcements") {
      const value = announcementSchema.safeParse(data); if (!value.success) return noStoreJson({ message: "Please check the announcement fields." }, 400);
      const startsAt = value.data.startsAt ? new Date(value.data.startsAt) : null;
      const endsAt = value.data.endsAt ? new Date(value.data.endsAt) : null;
      if ((startsAt && isNaN(startsAt.getTime())) || (endsAt && isNaN(endsAt.getTime())) || (startsAt && endsAt && endsAt <= startsAt)) return noStoreJson({ message: "Please check the publication window." }, 400);
      const v = { title: value.data.title, body: value.data.body, status: value.data.status, startsAt, endsAt };
      if (id) await db.update(announcements).set(v).where(eq(announcements.id, id)); else await db.insert(announcements).values(v);
    }
    await writeAudit(user.id, id ? "content.update" : "content.create", entity, id || undefined, { fieldGroup: entity });
    return noStoreJson({ ok: true });
  } catch { return noStoreJson({ message: "Unable to save content. Check for duplicate slugs or invalid fields." }, 400); }
}
