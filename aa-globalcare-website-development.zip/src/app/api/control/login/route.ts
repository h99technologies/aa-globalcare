import { z } from "zod";
import { db } from "@/db";
import { userRoles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSupabaseServer, isAuthConfigured } from "@/lib/auth";
import { acceptsJson, noStoreJson, rateLimit, sameOrigin, writeAudit } from "@/lib/security";

export const dynamic = "force-dynamic";
const input = z.object({ email: z.email().max(254), password: z.string().min(1).max(500) });
export async function POST(request: Request) {
  if (!sameOrigin(request) || !acceptsJson(request)) return noStoreJson({ message: "Invalid request." }, 400);
  if (!isAuthConfigured()) return noStoreJson({ message: "Private access has not been configured yet." }, 503);
  try {
    if (!(await rateLimit("control-login", request, 7, 900))) return noStoreJson({ message: "Too many attempts. Please try again later." }, 429);
    const parsed = input.safeParse(await request.json());
    if (!parsed.success) return noStoreJson({ message: "Please enter a valid email and password." }, 400);
    const supabase = await getSupabaseServer();
    if (!supabase) return noStoreJson({ message: "Private access is unavailable." }, 503);
    const { error } = await supabase.auth.signInWithPassword(parsed.data);
    if (error) return noStoreJson({ message: "Unable to sign in with those details." }, 401);
    const { data: { user }, error: verifyError } = await supabase.auth.getUser();
    if (verifyError || !user) { await supabase.auth.signOut(); return noStoreJson({ message: "Unable to sign in with those details." }, 401); }
    const [role] = await db.select({ role: userRoles.role }).from(userRoles).where(eq(userRoles.userId, user.id)).limit(1);
    if (!role) { await supabase.auth.signOut(); return noStoreJson({ message: "This account does not have control access." }, 403); }
    await writeAudit(user.id, "auth.login", "user_roles", user.id);
    return noStoreJson({ ok: true, role: role.role });
  } catch { return noStoreJson({ message: "Sign in is temporarily unavailable. Please try again later." }, 503); }
}
