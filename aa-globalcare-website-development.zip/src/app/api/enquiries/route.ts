import { z } from "zod";
import { db } from "@/db";
import { destinations, enquiries, integrationSettings, services, siteSettings } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { deliverNotifications } from "@/lib/notifications";
import { acceptsJson, noStoreJson, rateLimit, sameOrigin, shortPlainText } from "@/lib/security";

export const dynamic = "force-dynamic";
const enquiryInput = z.object({
  fullName: z.string().trim().min(2).max(120), email: z.email().max(254),
  phone: z.string().trim().regex(/^[+\d().\-\s]{7,30}$/),
  service: z.string().trim().min(1).max(100), destination: z.string().max(100).optional().default(""),
  message: z.string().trim().min(10).max(3000), consent: z.literal(true),
  website: z.string().max(100).optional().default(""),
});
export async function POST(request: Request) {
  if (!sameOrigin(request) || !acceptsJson(request)) return noStoreJson({ message: "Invalid request." }, 400);
  try {
    if (!(await rateLimit("public-enquiry", request, 5, 3600))) return noStoreJson({ message: "Please wait before sending another enquiry, or call us directly." }, 429);
    const parsed = enquiryInput.safeParse(await request.json());
    if (!parsed.success) return noStoreJson({ message: "Please check the required fields and try again." }, 400);
    if (parsed.data.website.trim()) return noStoreJson({ ok: true }); // Honeypot: do not reveal which signal was tripped.
    const [settings] = await db.select({ siteStatus: siteSettings.siteStatus }).from(siteSettings).where(eq(siteSettings.id, 1)).limit(1);
    if (!settings || settings.siteStatus !== "live") return noStoreJson({ message: "Online enquiries are temporarily unavailable. Please contact us by phone." }, 503);
    if (parsed.data.service !== "not-sure") {
      const [service] = await db.select({ id: services.id }).from(services).where(and(eq(services.slug, parsed.data.service), eq(services.active, true))).limit(1);
      if (!service) return noStoreJson({ message: "Please choose an available service." }, 400);
    }
    if (parsed.data.destination) {
      const [destination] = await db.select({ id: destinations.id }).from(destinations).where(and(eq(destinations.slug, parsed.data.destination), eq(destinations.visible, true))).limit(1);
      if (!destination) return noStoreJson({ message: "Please choose an available destination or leave it undecided." }, 400);
    }
    const [saved] = await db.insert(enquiries).values({
      fullName: shortPlainText(parsed.data.fullName, 120), email: parsed.data.email.trim().toLowerCase(),
      phone: shortPlainText(parsed.data.phone, 30), service: parsed.data.service,
      destination: parsed.data.destination || null, message: shortPlainText(parsed.data.message, 3000),
      consentAt: new Date(),
    }).returning();
    const [integration] = await db.select().from(integrationSettings).where(eq(integrationSettings.id, 1)).limit(1);
    if (integration) { try { await deliverNotifications(saved, integration); } catch { /* Enquiry already stored; operators can review it privately. */ } }
    return noStoreJson({ ok: true, message: "Your enquiry has been received." }, 201);
  } catch { return noStoreJson({ message: "We couldn't receive your enquiry right now. Please call us directly." }, 503); }
}
