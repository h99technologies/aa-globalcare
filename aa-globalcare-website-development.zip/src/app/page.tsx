import type { Metadata } from "next";
import { getPublicContent } from "@/lib/data";
import { PublicSite } from "@/components/public-site";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const { settings } = await getPublicContent();
  const base = process.env.PUBLIC_SITE_URL;
  return {
    title: settings.seoTitle, description: settings.seoDescription,
    alternates: base ? { canonical: new URL("/", base).toString() } : undefined,
    openGraph: { title: settings.seoTitle, description: settings.seoDescription,
      type: "website", images: [{ url: "/images/hero-fallback.jpg", width: 1200, height: 675, alt: "Airplane above the earth" }] },
    robots: settings.siteStatus === "live" ? { index: true, follow: true } : { index: false, follow: false },
  };
}

export default async function HomePage() {
  const content = await getPublicContent();
  return <PublicSite content={content} />;
}
