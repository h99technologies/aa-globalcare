import type { MetadataRoute } from "next";
import { getPublicSettings } from "@/lib/data";
export const dynamic = "force-dynamic";
export default async function robots(): Promise<MetadataRoute.Robots> {
  const settings = await getPublicSettings();
  const base = process.env.PUBLIC_SITE_URL;
  return {
    rules: settings.siteStatus === "live" ? { userAgent: "*", allow: "/", disallow: ["/control", "/api/control", "/api/enquiries", "/api/assistant"] } : { userAgent: "*", disallow: "/" },
    sitemap: base && settings.siteStatus === "live" ? new URL("/sitemap.xml", base).toString() : undefined,
  };
}
