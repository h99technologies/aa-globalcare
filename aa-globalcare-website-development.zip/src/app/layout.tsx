import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "A&A Globalcare Consultant Ltd.", template: "%s | A&A Globalcare" },
  description: "Thoughtful guidance for travel, visa applications, international study and career planning.",
  applicationName: "A&A Globalcare Consultant Ltd.",
  icons: { icon: "/icon.svg" },
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#061426" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
