import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { getPublicSettings } from "@/lib/data";
import { defaultContent } from "@/lib/content";
import { Maintenance } from "@/components/public-site";
import { SiteHeader, SiteFooter } from "@/components/site-chrome";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Terms of Use (Draft)", robots: { index: false, follow: false } };
export default async function TermsPage() {
  const settings = await getPublicSettings();
  if (settings.siteStatus !== "live") return <Maintenance content={{ ...defaultContent, settings }} />;
  return <><SiteHeader settings={settings} dark /><main className="legal-page"><div className="container-wide legal-wrap"><span className="eyebrow eyebrow-blue"><span className="eyebrow-line" /> PLEASE READ</span><h1>Terms of Use</h1><p className="legal-draft">Draft for company and legal review before launch. This text is not legal advice.</p><p className="legal-body">{settings.termsBody}</p><p className="legal-body" style={{ marginTop: 26 }}>{settings.disclaimer}</p><Link href="/" className="text-link dark-link"><ArrowLeft size={17} /> Back to home</Link></div></main><SiteFooter settings={settings} /></>;
}
