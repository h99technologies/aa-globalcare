import type { MetadataRoute } from "next";
import { getPublicSettings } from "@/lib/data";
export const dynamic = "force-dynamic";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.PUBLIC_SITE_URL;
  if (!base) return [];
  try {
    const settings = await getPublicSettings();
    if (settings.siteStatus !== "live") return [];
    return [{ url: new URL("/", base).toString(), changeFrequency: "weekly", priority: 1 }];
  } catch { return []; }
}
