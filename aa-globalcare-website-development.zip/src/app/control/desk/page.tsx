import { redirect } from "next/navigation";
import { getControlUser } from "@/lib/auth";
import { loadControlData } from "@/lib/control-data";
import { ControlDashboard } from "@/components/control-dashboard";
export const dynamic = "force-dynamic";
export default async function DeskPage() {
  const user = await getControlUser();
  if (!user) redirect("/control");
  const data = await loadControlData(user.role);
  return <ControlDashboard user={user} initialData={data} />;
}
