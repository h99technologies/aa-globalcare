import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./control.css";
export const metadata: Metadata = { title: "Private Control", robots: { index: false, follow: false, noarchive: true } };
export default function ControlLayout({ children }: { children: ReactNode }) { return <>{children}</>; }
