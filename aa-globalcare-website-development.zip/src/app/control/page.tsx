import { redirect } from "next/navigation";
import { getControlUser, isAuthConfigured } from "@/lib/auth";
import { ControlLogin } from "@/components/control-login";
export const dynamic = "force-dynamic";
export default async function ControlPage() {
  const user = await getControlUser();
  if (user) redirect("/control/desk");
  return <ControlLogin configured={isAuthConfigured()} />;
}
