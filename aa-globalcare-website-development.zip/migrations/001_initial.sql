-- A&A Globalcare schema v1. Run with a private PostgreSQL connection or Supabase SQL editor.
-- Safe to re-run: no destructive resets, data inserts use ON CONFLICT DO NOTHING.
BEGIN;
SELECT pg_advisory_xact_lock(hashtext('aa-globalcare-schema-v1'));
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS public.site_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  brand_name text NOT NULL, hero_headline text NOT NULL, hero_subheadline text NOT NULL,
  introduction text NOT NULL, address text NOT NULL, address_confirmed boolean NOT NULL DEFAULT false,
  phone_primary text NOT NULL, phone_secondary text NOT NULL, public_email text, whatsapp text, map_url text,
  support_24h_confirmed boolean NOT NULL DEFAULT false,
  site_status text NOT NULL DEFAULT 'live' CHECK (site_status IN ('live','maintenance','suspended')),
  status_message text NOT NULL, disclaimer text NOT NULL, privacy_body text NOT NULL, terms_body text NOT NULL,
  seo_title text NOT NULL, seo_description text NOT NULL, section_order jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), slug text NOT NULL UNIQUE, title text NOT NULL,
  summary text NOT NULL, body text NOT NULL, includes jsonb NOT NULL DEFAULT '[]'::jsonb,
  image_key text NOT NULL, video_key text NOT NULL, sort_order integer NOT NULL DEFAULT 0,
  active boolean NOT NULL DEFAULT true, seo_title text, seo_description text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS services_order_idx ON public.services (active, sort_order);
CREATE TABLE IF NOT EXISTS public.destinations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), country text NOT NULL, slug text NOT NULL UNIQUE,
  summary text NOT NULL, service_notes text NOT NULL, image_key text NOT NULL,
  video_key text NOT NULL DEFAULT 'cities', visible boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS destinations_order_idx ON public.destinations (visible, sort_order);
CREATE TABLE IF NOT EXISTS public.faqs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), question text NOT NULL, answer text NOT NULL,
  category text NOT NULL DEFAULT 'General', sort_order integer NOT NULL DEFAULT 0,
  published boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS faqs_order_idx ON public.faqs (published, sort_order);
CREATE TABLE IF NOT EXISTS public.testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), quote text NOT NULL, display_name text NOT NULL,
  role_location text, consented boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  sort_order integer NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS testimonials_status_idx ON public.testimonials (status, sort_order);
CREATE TABLE IF NOT EXISTS public.gallery (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), title text NOT NULL, asset_url text NOT NULL,
  alt text NOT NULL, category text NOT NULL DEFAULT 'travel', sort_order integer NOT NULL DEFAULT 0,
  visible boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS gallery_order_idx ON public.gallery (visible, sort_order);
CREATE TABLE IF NOT EXISTS public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), title text NOT NULL, body text NOT NULL,
  starts_at timestamptz, ends_at timestamptz,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published')),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS announcements_window_idx ON public.announcements (status, starts_at, ends_at);
CREATE TABLE IF NOT EXISTS public.enquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), full_name text NOT NULL, email text NOT NULL,
  phone text NOT NULL, service text NOT NULL, destination text, message text NOT NULL,
  attachment_metadata jsonb, consent_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new','contacted','resolved')),
  private_notes text NOT NULL DEFAULT '', created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS enquiries_status_created_idx ON public.enquiries (status, created_at DESC);
CREATE TABLE IF NOT EXISTS public.user_roles (
  user_id uuid PRIMARY KEY, role text NOT NULL CHECK (role IN ('admin','developer')),
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.ai_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  provider text NOT NULL DEFAULT 'disabled' CHECK (provider IN ('disabled','xai','groq')),
  model text NOT NULL DEFAULT '', enabled boolean NOT NULL DEFAULT false,
  additional_guidance text NOT NULL DEFAULT '', retention_days integer NOT NULL DEFAULT 30 CHECK (retention_days BETWEEN 1 AND 365),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.integration_settings (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  brevo_enabled boolean NOT NULL DEFAULT false, brevo_sender_name text, brevo_sender_email text,
  notification_email text, telegram_enabled boolean NOT NULL DEFAULT false,
  whatsapp_verified boolean NOT NULL DEFAULT false, updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), actor_user_id uuid, action text NOT NULL,
  target_type text NOT NULL, target_id text, safe_metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_logs_created_idx ON public.audit_logs (created_at DESC);
CREATE TABLE IF NOT EXISTS public.notification_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), enquiry_id uuid NOT NULL REFERENCES public.enquiries(id) ON DELETE CASCADE,
  channel text NOT NULL CHECK (channel IN ('brevo','telegram')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','failed','not_configured')),
  attempts integer NOT NULL DEFAULT 0, last_error text,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT notification_enquiry_channel_idx UNIQUE (enquiry_id, channel)
);
CREATE TABLE IF NOT EXISTS public.ai_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), session_id text NOT NULL,
  question text NOT NULL, answer text NOT NULL, consent_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ai_conversations_created_idx ON public.ai_conversations (created_at DESC);
CREATE TABLE IF NOT EXISTS public.rate_limits (
  key text PRIMARY KEY, count integer NOT NULL DEFAULT 0, expires_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS public.app_migrations (
  version text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;
DO $$ DECLARE table_name text; BEGIN
  FOREACH table_name IN ARRAY ARRAY['site_settings','services','destinations','faqs','testimonials','gallery','announcements','enquiries','user_roles','ai_settings','integration_settings','notification_deliveries'] LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'touch_' || table_name AND tgrelid = ('public.' || table_name)::regclass) THEN
      EXECUTE format('CREATE TRIGGER %I BEFORE UPDATE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.set_updated_at()', 'touch_' || table_name, table_name);
    END IF;
  END LOOP;
END $$;

-- PostgREST sets request.jwt.claim.sub from a verified JWT. Never accept this header directly at the app server.
CREATE OR REPLACE FUNCTION public.request_actor_id() RETURNS uuid LANGUAGE sql STABLE AS $$
  SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$$;
CREATE OR REPLACE FUNCTION public.has_control_role(requested_role text) RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles r WHERE r.user_id = public.request_actor_id() AND r.role = requested_role);
$$;
CREATE OR REPLACE FUNCTION public.is_control_user() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles r WHERE r.user_id = public.request_actor_id() AND r.role IN ('admin','developer'));
$$;
CREATE OR REPLACE FUNCTION public.guard_developer_settings() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF current_user = 'authenticated' AND
     (NEW.site_status IS DISTINCT FROM OLD.site_status OR NEW.status_message IS DISTINCT FROM OLD.status_message)
     AND NOT public.has_control_role('developer') THEN
    RAISE EXCEPTION 'Developer authorization required';
  END IF;
  RETURN NEW;
END $$;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='guard_site_status' AND tgrelid='public.site_settings'::regclass) THEN
    CREATE TRIGGER guard_site_status BEFORE UPDATE ON public.site_settings
    FOR EACH ROW EXECUTE FUNCTION public.guard_developer_settings();
  END IF;
END $$;

INSERT INTO public.site_settings
(id, brand_name, hero_headline, hero_subheadline, introduction, address, phone_primary, phone_secondary,
 status_message, disclaimer, privacy_body, terms_body, seo_title, seo_description, section_order)
VALUES (1, 'A&A Globalcare Consultant Ltd.', 'Your Next Chapter Starts Beyond Borders.',
 'Thoughtful guidance for travel, visa applications, international study and career planning.',
 'A&A Globalcare Consultant Ltd. helps people explore international travel, study and career pathways with clear guidance and personalised support. Contact our team to discuss your goals and understand the next steps relevant to your destination.',
 'Shop C_9 Arotech Plaza AEDC. Office before Optima Filling Station ASO Road, Maraba, Abuja, Nigeria.',
 '+237682081801', '+2348034759488',
 'We are making some improvements. Please contact us by phone while our website is unavailable.',
 'Visa, admission, travel and employment decisions are made by the relevant authorities, institutions, carriers or employers. Requirements and outcomes vary. A&A Globalcare Consultant Ltd. does not guarantee approval, admission, employment or immigration outcomes. Please confirm the exact legal wording with the company.',
 'DRAFT FOR COMPANY AND LEGAL REVIEW. We collect the details you submit in our enquiry form to respond to your request. We may share the relevant details with our team and configured notification providers to handle your enquiry. We do not sell enquiry details. Contact us by phone to request access, correction or deletion. Our retention schedule and applicable legal basis require owner confirmation before launch.',
 'DRAFT FOR COMPANY AND LEGAL REVIEW. Information on this website is general guidance, not legal, immigration or financial advice. Services and requirements depend on your circumstances and destination. No outcome is guaranteed. Contact us to discuss the current scope of any service. Confirm all legal terms with the company before launch.',
 'A&A Globalcare Consultant Ltd. | Travel, Study & Career Guidance',
 'Explore travel bookings, visa application assistance, study abroad and career consultation with A&A Globalcare Consultant Ltd.',
 '["destinations","services","visa","study","career","experience","process","about","journal","faqs","contact"]'::jsonb)
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.services (slug, title, summary, body, includes, image_key, video_key, sort_order) VALUES
('travel-bookings', 'Travel Bookings', 'Travel plans that begin with a conversation, not a complicated search.', 'Explore local and international flight options with support tailored to your itinerary. We can help you think through routes, timing and the practical details of your journey.', '["Local & international flight enquiries","Itinerary planning support","Travel preparation guidance"]'::jsonb, 'airport', 'airport', 1),
('visa-assistance', 'Visa Assistance', 'A clearer way to navigate the application process.', 'Get guidance for tourist, business, student and work visa applications. Requirements differ by destination and application type; decisions always rest with the relevant authorities.', '["Understanding application requirements","Document checklist guidance","Preparation and next-step support"]'::jsonb, 'passport', 'visa', 2),
('study-abroad', 'Study Abroad', 'Make room for the education you imagine.', 'Explore universities worldwide and understand the steps involved in planning an international education. We can help you organise your questions, documents and next steps.', '["Exploring study options","Entry-requirement discussions","Application preparation support"]'::jsonb, 'campus', 'study', 3),
('employment-programs', 'Employment Programs', 'Think internationally about your next career chapter.', 'Discuss your international career goals and the steps that may be relevant to them. Availability and eligibility depend on the destination and programme; employment outcomes are never guaranteed.', '["Career goal conversations","Pathway and requirement discussions","Preparation guidance"]'::jsonb, 'professional', 'career', 4)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.destinations (country, slug, summary, service_notes, image_key, sort_order) VALUES
('Canada', 'canada', 'Canada appears on the company''s supplied destination flyer. Ask us about current options and requirements before making plans.', 'Destination shown on supplied material; current services and programme availability require company confirmation.', 'canada', 1),
('United Kingdom', 'united-kingdom', 'United Kingdom appears on the company''s supplied destination flyer. Ask us about current options and requirements before making plans.', 'Destination shown on supplied material; current services and programme availability require company confirmation.', 'uk', 2),
('United States', 'united-states', 'United States appears on the company''s supplied destination flyer. Ask us about current options and requirements before making plans.', 'Destination shown on supplied material; current services and programme availability require company confirmation.', 'us', 3),
('United Arab Emirates', 'united-arab-emirates', 'United Arab Emirates appears on the company''s supplied destination flyer. Ask us about current options and requirements before making plans.', 'Destination shown on supplied material; current services and programme availability require company confirmation.', 'uae', 4),
('Oman', 'oman', 'Oman appears on the company''s supplied destination flyer. Ask us about current options and requirements before making plans.', 'Destination shown on supplied material; current services and programme availability require company confirmation.', 'oman', 5),
('Turkey', 'turkey', 'Turkey appears on the company''s supplied destination flyer. Ask us about current options and requirements before making plans.', 'Destination shown on supplied material; current services and programme availability require company confirmation.', 'turkey', 6),
('Georgia', 'georgia', 'Georgia appears on the company''s supplied destination flyer. Ask us about current options and requirements before making plans.', 'Destination shown on supplied material; current services and programme availability require company confirmation.', 'georgia', 7),
('Albania', 'albania', 'Albania appears on the company''s supplied destination flyer. Ask us about current options and requirements before making plans.', 'Destination shown on supplied material; current services and programme availability require company confirmation.', 'albania', 8)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO public.faqs (question, answer, category, sort_order, published)
SELECT seeded.question, seeded.answer, seeded.category, seeded.sort_order, seeded.published
FROM (VALUES
('What services can A&A Globalcare help me explore?', 'We offer support with local and international travel bookings, tourist, business, student and work visa applications, study abroad exploration, and international career planning. Contact us to discuss the current scope of support for your situation.', 'Services', 1, true),
('Which destinations can I ask about?', 'Our supplied material mentions Canada, the United Kingdom, the United States, the United Arab Emirates, Oman, Turkey, Georgia and Albania. These are candidate destinations, not a promise that every service is currently available in every location. Please enquire for current information.', 'Destinations', 2, true),
('What documents will I need?', 'Requirements vary by destination, application type and the relevant authority or institution. After an initial conversation, we can help you understand what to check and prepare. Always confirm current requirements with official sources.', 'Applications', 3, true),
('Can you guarantee a visa, admission or job?', 'No. Final decisions are made by the relevant authorities, institutions or employers. We provide guidance and preparation support; no approval, admission, employment or immigration outcome can be guaranteed.', 'Process', 4, true),
('How do I begin?', 'Tell us what you are planning through the enquiry form or call one of the numbers on this site. We can discuss your goal and suggest appropriate next steps.', 'Consultation', 5, true)
) AS seeded(question, answer, category, sort_order, published)
WHERE NOT EXISTS (SELECT 1 FROM public.faqs f WHERE f.question = seeded.question);

INSERT INTO public.ai_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
INSERT INTO public.integration_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;
INSERT INTO public.app_migrations (version) VALUES ('001_initial') ON CONFLICT (version) DO NOTHING;

-- RLS is defence-in-depth for Supabase/PostgREST. The server's private SQL connection
-- can bypass RLS and MUST authorize every privileged request before using Drizzle.
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.destinations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.gallery ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enquiries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.integration_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rate_limits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.app_migrations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS site_settings_read ON public.site_settings;
CREATE POLICY site_settings_read ON public.site_settings FOR SELECT USING (id = 1);
DROP POLICY IF EXISTS site_settings_write ON public.site_settings;
CREATE POLICY site_settings_write ON public.site_settings FOR UPDATE USING (public.is_control_user()) WITH CHECK (public.is_control_user());
DROP POLICY IF EXISTS services_read ON public.services;
CREATE POLICY services_read ON public.services FOR SELECT USING (active OR public.is_control_user());
DROP POLICY IF EXISTS services_write ON public.services;
CREATE POLICY services_write ON public.services FOR ALL USING (public.is_control_user()) WITH CHECK (public.is_control_user());
DROP POLICY IF EXISTS destinations_read ON public.destinations;
CREATE POLICY destinations_read ON public.destinations FOR SELECT USING (visible OR public.is_control_user());
DROP POLICY IF EXISTS destinations_write ON public.destinations;
CREATE POLICY destinations_write ON public.destinations FOR ALL USING (public.is_control_user()) WITH CHECK (public.is_control_user());
DROP POLICY IF EXISTS faqs_read ON public.faqs;
CREATE POLICY faqs_read ON public.faqs FOR SELECT USING (published OR public.is_control_user());
DROP POLICY IF EXISTS faqs_write ON public.faqs;
CREATE POLICY faqs_write ON public.faqs FOR ALL USING (public.is_control_user()) WITH CHECK (public.is_control_user());
DROP POLICY IF EXISTS testimonials_read ON public.testimonials;
CREATE POLICY testimonials_read ON public.testimonials FOR SELECT USING ((status = 'approved' AND consented) OR public.is_control_user());
DROP POLICY IF EXISTS testimonials_write ON public.testimonials;
CREATE POLICY testimonials_write ON public.testimonials FOR ALL USING (public.is_control_user()) WITH CHECK (public.is_control_user());
DROP POLICY IF EXISTS gallery_read ON public.gallery;
CREATE POLICY gallery_read ON public.gallery FOR SELECT USING (visible OR public.is_control_user());
DROP POLICY IF EXISTS gallery_write ON public.gallery;
CREATE POLICY gallery_write ON public.gallery FOR ALL USING (public.is_control_user()) WITH CHECK (public.is_control_user());
DROP POLICY IF EXISTS announcements_read ON public.announcements;
CREATE POLICY announcements_read ON public.announcements FOR SELECT USING (
  (status = 'published' AND (starts_at IS NULL OR starts_at <= now()) AND (ends_at IS NULL OR ends_at >= now())) OR public.is_control_user()
);
DROP POLICY IF EXISTS announcements_write ON public.announcements;
CREATE POLICY announcements_write ON public.announcements FOR ALL USING (public.is_control_user()) WITH CHECK (public.is_control_user());
DROP POLICY IF EXISTS enquiries_control ON public.enquiries;
CREATE POLICY enquiries_control ON public.enquiries FOR ALL USING (public.is_control_user()) WITH CHECK (public.is_control_user());
DROP POLICY IF EXISTS user_roles_read ON public.user_roles;
CREATE POLICY user_roles_read ON public.user_roles FOR SELECT USING (user_id = public.request_actor_id() OR public.has_control_role('developer'));
DROP POLICY IF EXISTS user_roles_developer ON public.user_roles;
CREATE POLICY user_roles_developer ON public.user_roles FOR ALL USING (public.has_control_role('developer')) WITH CHECK (public.has_control_role('developer'));
DROP POLICY IF EXISTS ai_settings_developer ON public.ai_settings;
CREATE POLICY ai_settings_developer ON public.ai_settings FOR ALL USING (public.has_control_role('developer')) WITH CHECK (public.has_control_role('developer'));
DROP POLICY IF EXISTS integrations_developer ON public.integration_settings;
CREATE POLICY integrations_developer ON public.integration_settings FOR ALL USING (public.has_control_role('developer')) WITH CHECK (public.has_control_role('developer'));
DROP POLICY IF EXISTS audit_read ON public.audit_logs;
CREATE POLICY audit_read ON public.audit_logs FOR SELECT USING (public.has_control_role('developer') OR actor_user_id = public.request_actor_id());
DROP POLICY IF EXISTS notifications_read ON public.notification_deliveries;
CREATE POLICY notifications_read ON public.notification_deliveries FOR SELECT USING (public.is_control_user());
DROP POLICY IF EXISTS conversations_control ON public.ai_conversations;
CREATE POLICY conversations_control ON public.ai_conversations FOR SELECT USING (public.is_control_user());
DROP POLICY IF EXISTS conversations_delete ON public.ai_conversations;
CREATE POLICY conversations_delete ON public.ai_conversations FOR DELETE USING (public.is_control_user());
DROP POLICY IF EXISTS migrations_developer ON public.app_migrations;
CREATE POLICY migrations_developer ON public.app_migrations FOR SELECT USING (public.has_control_role('developer'));

DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'anon') THEN
    GRANT USAGE ON SCHEMA public TO anon;
    GRANT SELECT ON public.site_settings, public.services, public.destinations, public.faqs, public.testimonials, public.gallery, public.announcements TO anon;
    REVOKE ALL ON public.enquiries, public.user_roles, public.ai_settings, public.integration_settings, public.audit_logs, public.notification_deliveries, public.ai_conversations, public.rate_limits, public.app_migrations FROM anon;
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'authenticated') THEN
    GRANT USAGE ON SCHEMA public TO authenticated;
    GRANT SELECT, INSERT, UPDATE, DELETE ON public.site_settings, public.services, public.destinations, public.faqs, public.testimonials, public.gallery, public.announcements, public.enquiries, public.user_roles, public.ai_settings, public.integration_settings, public.ai_conversations TO authenticated;
    GRANT SELECT ON public.audit_logs, public.notification_deliveries, public.app_migrations TO authenticated;
    REVOKE ALL ON public.rate_limits FROM authenticated;
  END IF;
END $$;
COMMIT;
