-- Optional encrypted at-rest integration credentials. The encryption key lives ONLY in deployment secrets.
BEGIN;
SELECT pg_advisory_xact_lock(hashtext('aa-globalcare-schema-v2'));
CREATE TABLE IF NOT EXISTS public.encrypted_secrets (
  name text PRIMARY KEY, ciphertext text NOT NULL, iv text NOT NULL, tag text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.encrypted_secrets ENABLE ROW LEVEL SECURITY;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='touch_encrypted_secrets' AND tgrelid='public.encrypted_secrets'::regclass) THEN
    CREATE TRIGGER touch_encrypted_secrets BEFORE UPDATE ON public.encrypted_secrets FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
  END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN REVOKE ALL ON public.encrypted_secrets FROM anon; END IF;
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN REVOKE ALL ON public.encrypted_secrets FROM authenticated; END IF;
END $$;
INSERT INTO public.app_migrations(version) VALUES('002_encrypted_secrets') ON CONFLICT(version) DO NOTHING;
COMMIT;
