-- On Supabase, enforce the relationship between private roles and authenticated users.
-- Local PostgreSQL previews without the auth schema skip the foreign key safely.
BEGIN;
SELECT pg_advisory_xact_lock(hashtext('aa-globalcare-schema-v3'));
DO $$ BEGIN
  IF to_regclass('auth.users') IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'user_roles_auth_user_fk' AND conrelid = 'public.user_roles'::regclass
  ) THEN
    ALTER TABLE public.user_roles ADD CONSTRAINT user_roles_auth_user_fk
      FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;
INSERT INTO public.app_migrations(version) VALUES('003_supabase_auth_link') ON CONFLICT(version) DO NOTHING;
COMMIT;
