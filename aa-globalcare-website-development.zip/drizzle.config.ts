import { defineConfig } from "drizzle-kit";
const url = process.env.SUPABASE_DB_URL || process.env.DATABASE_URL;
if (!url) throw new Error("Set SUPABASE_DB_URL or DATABASE_URL privately before running drizzle-kit.");
export default defineConfig({ schema: "./src/db/schema.ts", dialect: "postgresql", dbCredentials: { url } });
