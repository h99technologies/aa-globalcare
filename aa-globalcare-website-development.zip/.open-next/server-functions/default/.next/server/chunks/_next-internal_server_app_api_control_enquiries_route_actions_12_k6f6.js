module.exports=[52762,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_control_enquiries_route_actions_12_k6f6.js.map