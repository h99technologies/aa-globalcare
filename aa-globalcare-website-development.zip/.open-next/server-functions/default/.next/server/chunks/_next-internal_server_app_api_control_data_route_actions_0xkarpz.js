module.exports=[69438,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_control_data_route_actions_0xkarpz.js.map