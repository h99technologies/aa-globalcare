module.exports=[8629,a=>{"use strict";var b=a.i(7997);a.s(["default",0,function({children:a}){return(0,b.jsx)(b.Fragment,{children:a})},"metadata",0,{title:"Private Control",robots:{index:!1,follow:!1,noarchive:!0}}])},89432,a=>{a.n(a.i(8629))}];

//# sourceMappingURL=src_app_control_layout_tsx_0ut6.v8._.js.map