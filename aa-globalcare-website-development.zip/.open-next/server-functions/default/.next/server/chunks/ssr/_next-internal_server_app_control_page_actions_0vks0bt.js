module.exports=[3606,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_control_page_actions_0vks0bt.js.map