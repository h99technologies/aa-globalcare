module.exports=[98993,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_control_desk_page_actions_0ubr.y7.js.map