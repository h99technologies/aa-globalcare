module.exports=[42288,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_control_logout_route_actions_0905mhg.js.map