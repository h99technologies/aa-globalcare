module.exports=[92465,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_control_login_route_actions_0o40kcd.js.map