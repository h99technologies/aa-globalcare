module.exports=[15596,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_control_manage_route_actions_0uo8h.t.js.map