var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/assistant/route.js")
R.c("server/chunks/_0rpaden._.js")
R.c("server/chunks/[root-of-the-server]__0-~-ad2._.js")
R.c("server/chunks/_0f7l3hq._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/[root-of-the-server]__11j~5mn._.js")
R.c("server/chunks/_next-internal_server_app_api_assistant_route_actions_0.znwuh.js")
R.m(89068)
module.exports=R.m(89068).exports
