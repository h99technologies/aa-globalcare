var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/enquiries/route.js")
R.c("server/chunks/[root-of-the-server]__006e_xc._.js")
R.c("server/chunks/_0f7l3hq._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/[root-of-the-server]__11j~5mn._.js")
R.c("server/chunks/_next-internal_server_app_api_enquiries_route_actions_0q94nv~.js")
R.m(80836)
module.exports=R.m(80836).exports
