var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/control/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0zuxh5-._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__11j~5mn._.js")
R.c("server/chunks/_12~i.2x._.js")
R.c("server/chunks/_0f7l3hq._.js")
R.c("server/chunks/_next-internal_server_app_api_control_logout_route_actions_0905mhg.js")
R.m(23750)
module.exports=R.m(23750).exports
