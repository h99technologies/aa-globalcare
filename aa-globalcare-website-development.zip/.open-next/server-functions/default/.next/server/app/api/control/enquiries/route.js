var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/control/enquiries/route.js")
R.c("server/chunks/[root-of-the-server]__0iljr-a._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/[root-of-the-server]__11j~5mn._.js")
R.c("server/chunks/_12~i.2x._.js")
R.c("server/chunks/_0f7l3hq._.js")
R.c("server/chunks/_next-internal_server_app_api_control_enquiries_route_actions_12_k6f6.js")
R.m(30500)
module.exports=R.m(30500).exports
