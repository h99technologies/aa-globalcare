var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0fm.4uv._.js")
R.c("server/chunks/node_modules_next_11synfn._.js")
R.c("server/chunks/_0f7l3hq._.js")
R.c("server/chunks/[root-of-the-server]__11j~5mn._.js")
R.c("server/chunks/node_modules_next_dist_0npcise._.js")
R.c("server/chunks/_next-internal_server_app_sitemap_xml_route_actions_036gxb_.js")
R.m(83345)
module.exports=R.m(83345).exports
