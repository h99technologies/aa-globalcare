# A&A Globalcare Consultant Ltd.

A cinematic public website and private Admin/Developer control area built with Next.js 16 (App Router), Drizzle ORM, PostgreSQL and Supabase Auth. The public site is server-rendered from CMS records. This repository has **no default account, password, provider key or customer enquiry data**.

## Important security action before launch

Credentials pasted into a chat or shared document must be considered exposed. **Rotate the database password, Developer password, Telegram bot token, Groq API key and Brevo API key before connecting them to production.** Do not reuse the pasted values. The supplied Supabase publishable key is designed for public use, but the project URL is still needed. No pasted credential was copied into source, environment templates or client code.

## Architecture and hosting

- Public pages: Next.js App Router, dynamic CMS reads through server-side Drizzle. All 43 supplied image URLs, the official logo URL, and all 12 MP4 URLs are preserved in `src/lib/assets.ts`. Local still images are **fallbacks**, not replacements for the owner-supplied sources.
- Private access: Supabase Auth email/password or invitation; one shared `/control` login. Each protected page and API operation checks `auth.getUser()` **and** the `user_roles` table. Only `admin` and `developer` exist. Supabase RLS adds defence in depth for PostgREST access. Server Drizzle connections can bypass RLS, so route authorization is mandatory.
- Storage: PostgreSQL. Enquiries, delivery outcomes, opt-in AI transcripts, audit records and encrypted integration credentials are private tables. No anonymous enquiry SELECT. Attachments are intentionally **not enabled**; accepting files without a fully configured private storage and malware/retention policy would be unsafe.
- Cloudflare: dynamic Next.js requires **Cloudflare Workers with the OpenNext adapter**, not static Cloudflare Pages export. `wrangler.jsonc` and `open-next.config.ts` are provided. The Arena preview runs in a Node.js environment; a Cloudflare Workers runtime build and real Supabase connection must be tested before claiming production compatibility. Cloudflare recommends Hyperdrive for PostgreSQL; the current `pg` adapter can use Supabase's connection pooler through a private `DATABASE_URL`. Test connection counts and latency in Workers. Use `nodejs_compat`.

## Local setup

1. Use Node.js 22+ and `npm ci`.
2. Copy `.env.example` to `.env.local` and fill **only your private local or deployment environment**. For the local starter PostgreSQL instance, set `DATABASE_URL` to its private connection string. Do not commit `.env.local`.
3. Run `node scripts/migrate.mjs` with `DATABASE_URL` set. This applies the additive, versioned SQL files in `migrations/` exactly once and seeds four services, eight **candidate** destinations and five cautious FAQs. It does not create testimonials or privileged users. The migration runner can be run repeatedly; it does not reset content.
4. Run `npm run dev`. Verify `/api/health` returns `{ "ok": true }`. The public site remains readable without any optional integration. `/control` honestly reports “not configured” until Supabase Auth settings are present.
5. Run `npx next typegen`, `npm exec tsc -- --noEmit --pretty false`, `npm run build` and `npm run lint` before deployment.

For Supabase use `SUPABASE_DB_URL` for migrations (a private role permitted to create tables and policies), and `DATABASE_URL` for runtime Drizzle queries (prefer a dedicated, least-privilege database user / Supabase pooler with TLS). Never use a database admin password in a browser or `NEXT_PUBLIC_*` variable. `drizzle.config.ts` also reads these environment variables; the versioned SQL migrations are the authoritative setup path, not an unrestricted browser setup endpoint.

## Supabase Auth and first Developer

1. Create/open the owner's Supabase project. Configure `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` as server-side deployment variables. **A publishable key alone is not enough; the exact project URL was not supplied.** Configure Supabase Auth email delivery, Site URL and approved redirect URLs for your real domain.
2. Apply migrations using the private DB URL or paste each versioned SQL file into the Supabase SQL editor **in numeric order** as a one-time manual fallback. The deploy script runs them automatically before building. Migration 003 adds a foreign key to `auth.users` when that schema exists.
3. Create a real Developer user in the Supabase Auth dashboard or through a secure invitation. Choose a **new, strong password**; no default password is shipped. Find that user's Auth UUID privately. In the Supabase SQL editor, once only, run:

   `INSERT INTO public.user_roles (user_id, role) VALUES ('<AUTH-USER-UUID>', 'developer') ON CONFLICT (user_id) DO UPDATE SET role = 'developer';`

4. Visit `/control`, sign in, then grant Admin roles to existing Auth UUIDs. Optionally set `SUPABASE_SECRET_KEY` **only as a server secret** to enable Developer-initiated Admin invitations. The service/secret key is not needed for normal public reads or login. The last Developer role cannot be removed or downgraded through the dashboard.
5. Supabase Auth stores password hashes and controls recovery/session expiry. Protected API requests revalidate the user and role. Keep Supabase email confirmation and password reset policies current. There is no public signup page.

## Environment variables

| Variable | Use |
|---|---|
| `DATABASE_URL` | Server-only runtime PostgreSQL connection. Required. |
| `SUPABASE_DB_URL` | Private migration connection, required by the Cloudflare deploy script. |
| `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY` | Server-side Supabase Auth project settings. Required for `/control`. |
| `SUPABASE_SECRET_KEY` | Optional **server-only** Supabase Auth Admin invitations. Never expose to browser. |
| `CONTROL_ENCRYPTION_KEY` | Optional 32-byte base64 AES key for Developer-entered credentials. Generate privately with `openssl rand -base64 32`. Back it up securely; losing it makes stored secrets unreadable. |
| `XAI_API_KEY` | Optional xAI provider. Different from a **Groq** key. |
| `GROQ_API_KEY` | Optional Groq Cloud provider. Configure AI provider `groq` in Developer settings. |
| `BREVO_API_KEY` | Optional transactional email API key. Verify sender/domain and private alert recipient before enabling. |
| `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` | Optional private owner/admin chat notifications. |
| `PUBLIC_SITE_URL` | Exact verified HTTPS canonical domain for sitemap/metadata. |
| `RATE_LIMIT_SALT` | Long private random value for stable hashed-IP rate limits. |
| `DB_POOL_MAX` | Optional connection pool cap, default 3. |

For xAI/Groq/Brevo/Telegram credentials, environment secrets take precedence. Alternatively, a Developer may enter **rotated** credentials in the dashboard after configuring `CONTROL_ENCRYPTION_KEY`; they are AES-256-GCM encrypted at rest, write-only in the UI, and never fetched back to the browser. Do not enter old pasted credentials. Enabling an integration does not prove it works: run the credential test and an approved end-to-end test. Brevo sends **only a private new-enquiry alert**; a customer acknowledgement is deliberately not sent until wording is approved.

## Cloudflare Workers deployment

1. In a trusted CI/build environment, provide `SUPABASE_DB_URL` and `DATABASE_URL` as private variables plus Supabase Auth settings. Workers runtime secrets must also be set separately with Wrangler or the Cloudflare dashboard (for example, `wrangler secret put DATABASE_URL`, `wrangler secret put SUPABASE_URL`, `wrangler secret put SUPABASE_PUBLISHABLE_KEY`). Never write values into `wrangler.jsonc`. The project uses the Workers OpenNext adapter version compatible with the installed Next.js release.
2. Run `bash scripts/deploy-cloudflare.sh`. It runs migrations **before** the OpenNext build and deploy. If automatic migrations are unavailable, run `node scripts/migrate.mjs` in trusted CI or use the one-time SQL editor fallback, then build/deploy separately. There is no public setup route.
3. In Cloudflare Workers → your Worker → Domains & Routes, attach the verified custom domain. Configure DNS/TLS, set `PUBLIC_SITE_URL` to that HTTPS origin, update Supabase Auth Site URL / redirect allow-list, and test `/api/health`, the public site and Auth on the real domain. For scale, configure Cloudflare Hyperdrive or a suitable Supabase pooler and test that `pg` connections remain healthy; this sandbox does **not** prove Cloudflare runtime compatibility.
4. Configure WAF/Turnstile and edge rate limits for abuse-prone public and login routes. The app has DB-backed hashed-IP rate limiting and honeypot checks, but proxy headers and distributed abuse controls still need production hardening. Configure backup retention and restoration tests in Supabase; do not assume backups are active on a particular plan.

## Content and integrations

- Admin edits services, destination candidates, FAQs, gallery, approved testimonials, announcements, public copy, enquiry status/notes, and privacy drafts. Developer can do all that plus maintenance/suspension, section order, roles, AI settings, integration configuration and encrypted credentials.
- Company phone numbers are the only preconfigured direct contact actions. Public email, WhatsApp and map links are hidden until provided; WhatsApp also requires Developer verification. The supplied address is displayed with a “call to confirm directions” note until confirmed. The flyer’s 24/7 claim remains hidden until confirmed.
- The AI assistant uses only published services, FAQs, destinations, disclaimer and Developer-approved guidance. xAI uses `https://api.x.ai/v1/chat/completions`; Groq Cloud uses its separate OpenAI-compatible endpoint. It is disabled by default and falls back to the human contact path when not configured or unavailable. No AI transcript is stored without opt-in.
- All background videos are muted, inline and looping. Only the hero is considered immediately; offscreen media are deferred/paused. Reduced-motion, data-saver and playback failures use local stills. The supplied image host did not respond from the build sandbox; confirm it from production and move assets to controlled storage such as Cloudflare R2/custom domain if needed. The separate unclear “Blue Sky” URL was not invented.

## Verification and privacy checklist

- Test at 360px, tablet, laptop and desktop widths in real browsers; keyboard navigation, mobile drawer, destination markers, accordions, CTA preselection, form states and reduced motion. This sandbox does not include a browser automation runtime, so device testing remains a launch task.
- Test all 12 MP4 URLs and all supplied image URLs from the deployment network. Third-party hotlink rules/retention are outside this app's control. Posters always remain available.
- In Supabase, test RLS using anon, an Auth user with no role, Admin and Developer. Anonymous SELECT of `enquiries`, `user_roles`, `integration_settings`, `ai_settings`, `audit_logs` and `encrypted_secrets` must fail; anonymous SELECT of public tables must show only published records. Admin cannot grant roles or change maintenance status; Developer can. Server endpoints must also return 401/403 without the role regardless of RLS.
- Submit a consented test enquiry in an approved environment. Confirm private storage, delivery states and failure retention. Do not use real customer data in testing. Test provider credentials only with rotated, valid keys. Verify no secrets appear in HTML/network responses, logs or source maps.
- Review/approve legal drafts, exact address/map pin, destinations/programme availability, support claim and notification wording with the owner before launch. Arrange a privacy/retention process and a data deletion contact path.

## Rollback

Keep a versioned copy of the last passing application build. If a deployment fails, redeploy that build and review the migration version in `app_migrations`. SQL migrations are additive and do not drop existing data; never run a destructive reset as rollback. Restore data only from a **tested** Supabase backup when necessary, after evaluating schema/app version compatibility. Rotate compromised credentials immediately and invalidate old tokens/sessions.
